(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.BMTN_Map_Master3pngcopy_newpngcopy3 = function() {
	this.initialize(img.BMTN_Map_Master3pngcopy_newpngcopy3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1546);


(lib.BMTN_Map_Master4_new = function() {
	this.initialize(img.BMTN_Map_Master4_new);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1546);


(lib.BMTN_Map_Master88_newpngcopy2 = function() {
	this.initialize(img.BMTN_Map_Master88_newpngcopy2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1546);


(lib.BMTN_Map_Master_5_new = function() {
	this.initialize(img.BMTN_Map_Master_5_new);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1546);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween2copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(2,1,1).p("AMLA4IA2g2Ig5g5AtAADIZxAA");
	this.shape.setTransform(-41.6875,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-126,-6.5,168.7,13.1);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(2,1,1).p("AmfACIM/AAIg5g5AGgACIg2A2");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.6,-6.5,85.30000000000001,13.1);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(2,1,1).p("AmfACIM/AAIg2A2AGgACIg5g5");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.6,-6.5,85.30000000000001,13.1);


(lib.Symbol99 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,0,0.176)").s().p("AjMNLIivrpICjjWInqksIBhimIBTiEIGXlUIGXiMIDkgZIiSC7IgCB7IC+C2IANBJIgtBpIgNB9IgyBSIhQB9IFEIhIhPE9IAtCtIgZB6Ig0BiIqKC2g");
	this.shape.setTransform(41.975,34.275);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28.7,-87.7,141.4,244);


(lib.Symbol98 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.BMTN_Map_Master3pngcopy_newpngcopy3();
	this.instance.setTransform(0,0,0.5004,0.4995);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol98, new cjs.Rectangle(0,0,1000.8,772.2), null);


(lib.Symbol97 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.BMTN_Map_Master4_new();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol97, new cjs.Rectangle(0,0,1000,773), null);


(lib.Symbol95 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.BMTN_Map_Master_5_new();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol95, new cjs.Rectangle(0,0,1000,773), null);


(lib.Symbol94 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ai1CqIiriNQgDgGGukXQAEgDB/CHIB/CGIAUBVIgMAsQh0BSgmARQgFADhNAGQhTAIgSADg");
	this.shape.setTransform(28.1999,23.3977);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol94, new cjs.Rectangle(-7.1,-2.3,70.6,51.5), null);


(lib.Symbol93 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AkqB4IABjPQgCgEA/g4QA9g3AdgUQAJgHDWgTQDTgTABACIAKBRIiBCyIhICfIgXByIAAAAIl1iTgAkqB4IAAAAIAAAAIAAAAg");
	this.shape.setTransform(29.7501,26.4446);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol93, new cjs.Rectangle(-0.2,-0.2,59.900000000000006,53.300000000000004), null);


(lib.Symbol89 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgQA9QgHgFgEgIQgEgJgBgLIARgEQAAAHABAGQACAHAEADQAEAEAGABQAGAAAEgEQAEgEAAgHQAAgJgEgGIgKgLIgVgSQgGgFgEgHQgDgGAAgKQAAgOAJgJQAIgHAOAAQAHAAAFACQAGACAEAEQAEAEADAHQACAFAAAJIgPAFQAAgHgCgGQgBgFgDgDQgFgDgFgBQgHABgEADQgDAEAAAHQAAAGABAEQACADAFAFIAVATQAHAFAGAJQAGAJgBAMQAAAJgDAIQgEAGgHAEQgHAEgJAAQgKAAgIgFg");
	this.shape.setTransform(150.5,52.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AgZBBIAAiBIASAAIAAB0IAhAAIAAANg");
	this.shape_1.setTransform(143.825,52.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s().p("AgIBBIAAiBIARAAIAACBg");
	this.shape_2.setTransform(138.3,52.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#666666").s().p("AATBBIgGghIgZAAIgGAhIgRAAIAbiBIARAAIAbCBgAALATIgLg5IgKA5IAVAAg");
	this.shape_3.setTransform(132.375,52.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#666666").s().p("AgIBBIAAhzIgVAAIAAgOIA7AAIAAAOIgVAAIAABzg");
	this.shape_4.setTransform(125.15,52.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#666666").s().p("AgYBBIAAiBIAxAAIAAAOIgfAAIAAAqIAZAAIAAAMIgZAAIAAAwIAfAAIAAANg");
	this.shape_5.setTransform(118.875,52.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#666666").s().p("AggBBIAAiBIAcAAQANAAAJAFQAIAEAEAJQADAJAAANIAAAuQAAAOgDAKQgEAJgIAFQgIAFgNAAgAgOA0IAKAAQAJAAAEgEQAEgEABgHIABgSIAAgpQAAgKgBgGQgBgHgFgDQgEgCgIAAIgKAAg");
	this.shape_6.setTransform(111.275,52.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#666666").s().p("AgYBBIAAiBIAxAAIAAAOIgfAAIAAAqIAZAAIAAAMIgZAAIAAAwIAfAAIAAANg");
	this.shape_7.setTransform(100.325,52.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#666666").s().p("AgYBBIAAiBIAxAAIAAAOIgfAAIAAAqIAZAAIAAAMIgZAAIAAAwIAfAAIAAANg");
	this.shape_8.setTransform(93.825,52.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#666666").s().p("AgQA9QgIgFgEgIQgDgJAAgLIAPgEQABAHACAGQABAHAEADQAEAEAFABQAHAAAFgEQADgEAAgHQAAgJgEgGIgKgLIgVgSQgHgFgDgHQgCgGAAgKQAAgOAIgJQAIgHAOAAQAGAAAHACQAGACADAEQAEAEACAHQADAFABAJIgQAFQAAgHgBgGQgCgFgEgDQgEgDgFgBQgHABgDADQgEAEgBAHQABAGACAEQACADAEAFIAVATQAHAFAGAJQAFAJABAMQAAAJgFAIQgDAGgIAEQgGAEgKAAQgJAAgIgFg");
	this.shape_9.setTransform(86.65,52.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#666666").s().p("AgUA9QgHgGgEgJQgEgKAAgMIAAgxQAAgMAEgJQAEgJAHgGQAIgEAMAAQAOAAAHAEQAIAGADAJQAEAJgBAMIAAAxQABAMgEAKQgDAJgIAGQgHAFgOAAQgMAAgIgFgAgKgwQgEADgBAEIgBANIAAA4IABANQABAFAEACQAEAEAGAAQAHAAAEgEQADgCACgFQABgGAAgHIAAg4QAAgHgBgGQgCgEgDgDQgEgDgHAAQgGAAgEADg");
	this.shape_10.setTransform(154.25,33.35);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#666666").s().p("AgHBBIAAhzIgWAAIAAgOIA7AAIAAAOIgVAAIAABzg");
	this.shape_11.setTransform(146.65,33.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#666666").s().p("AAUBBIgkhYIAABYIgPAAIAAiBIANAAIAjBVIAAhVIAPAAIAACBg");
	this.shape_12.setTransform(135.5,33.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#666666").s().p("AgUA9QgHgGgEgJQgEgKABgMIAAgxQgBgMAEgJQAEgJAHgGQAIgEAMAAQAOAAAHAEQAHAGAEAJQAEAJAAAMIAAAxQAAAMgEAKQgEAJgHAGQgHAFgOAAQgMAAgIgFgAgKgwQgEADgBAEIgBANIAAA4IABANQABAFAEACQAEAEAGAAQAIAAADgEQAEgCABgFQACgGAAgHIAAg4QAAgHgCgGQgBgEgEgDQgDgDgIAAQgGAAgEADg");
	this.shape_13.setTransform(127,33.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#666666").s().p("AgIBBIAAiBIARAAIAACBg");
	this.shape_14.setTransform(120.75,33.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#666666").s().p("AgIBBIAAhzIgVAAIAAgOIA8AAIAAAOIgWAAIAABzg");
	this.shape_15.setTransform(115.45,33.325);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#666666").s().p("AgTA8QgIgFgDgLQgDgJAAgMIAAgtQAAgNADgKQADgKAIgFQAIgFAMAAQAMAAAIAEQAHAFADAIQADAIAAAMIAAAKIgRAAIAAgJIgBgMQgBgGgDgDQgDgDgIAAQgGAAgEADQgDADgBAHIgBANIAAAzQAAAKABAFQACAGAEADQADACAFAAQAIAAADgEQADgDABgGIABgNIAAgJIARAAIAAAJQAAAMgDAJQgDAJgHAFQgHAFgNAAQgMAAgIgGg");
	this.shape_16.setTransform(108.075,33.35);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#666666").s().p("AgYBBIAAiBIAxAAIAAAOIgfAAIAAAqIAZAAIAAAMIgZAAIAAAwIAfAAIAAANg");
	this.shape_17.setTransform(100.975,33.325);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#666666").s().p("AgQA9QgHgEgEgJQgEgIgBgMIARgEQAAAHABAGQACAGAEAEQAEAFAGAAQAGgBAEgDQAEgEAAgIQAAgJgEgEIgKgMIgVgSQgGgFgEgHQgDgGAAgLQAAgOAIgHQAJgIAOAAQAHAAAFACQAGACAEAEQAEAEADAHQACAFAAAJIgPAFQAAgHgCgFQgBgGgDgDQgFgDgFgBQgHAAgEAFQgDADAAAHQAAAGABAEQACADAFAFIAVATQAHAFAGAJQAGAJgBAMQAAAJgDAIQgEAGgHAEQgHAEgJAAQgKAAgIgFg");
	this.shape_18.setTransform(93.8,33.35);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#666666").s().p("AATBBIgGghIgZAAIgGAhIgRAAIAbiBIARAAIAbCBgAALATIgLg5IgKA5IAVAAg");
	this.shape_19.setTransform(82.325,33.325);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#666666").s().p("AgYBBIAAiBIAxAAIAAAOIgfAAIAAAqIAZAAIAAAMIgZAAIAAAwIAfAAIAAANg");
	this.shape_20.setTransform(162.725,14.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#666666").s().p("AgQA9QgHgFgEgIQgEgJgBgLIAQgEQAAAHACAGQACAGAEAFQAEADAFAAQAIAAADgDQAEgEAAgIQAAgIgEgFIgKgLIgVgTQgGgFgDgHQgEgHAAgKQABgOAHgHQAJgIAOAAQAHAAAFACQAGACAEAEQAEAEADAGQACAGAAAJIgPAEQAAgGgCgFQgBgFgDgEQgFgEgFAAQgHABgEAEQgDADgBAHQAAAGACADQACAEAFAEIAVATQAHAGAGAJQAGAJgBAMQAAAJgEAHQgEAHgGAEQgHAEgKAAQgKAAgHgFg");
	this.shape_21.setTransform(155.55,14.65);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#666666").s().p("AgUA9QgHgFgEgKQgEgKABgMIAAgxQgBgMAEgKQAEgJAHgFQAIgEAMAAQANAAAIAEQAIAGADAJQAEAJAAAMIAAAxQAAAMgEAKQgDAKgIAFQgIAFgNAAQgMAAgIgFgAgJgwQgEACgCAGIgBAMIAAA4IABANQACAFAEADQADACAGAAQAIAAADgCQAEgDABgFQACgGAAgHIAAg4QAAgHgCgFQgBgGgEgCQgDgDgIAAQgGAAgDADg");
	this.shape_22.setTransform(147.35,14.65);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#666666").s().p("AgTA9QgJgFgDgKQgDgKgBgMIAAgxQABgMADgKQADgJAJgFQAHgEAMAAQANAAAIAEQAIAGADAJQADAJAAAMIAAAxQAAAMgDAKQgDAKgIAFQgIAFgNAAQgMAAgHgFgAgKgwQgDACgCAGIgBAMIAAA4IABANQACAFADADQAEACAGAAQAHAAAEgCQADgDACgFQACgGgBgHIAAg4QABgHgCgFQgCgGgDgCQgEgDgHAAQgGAAgEADg");
	this.shape_23.setTransform(138.75,14.65);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#666666").s().p("AARBBIAAg9IghAAIAAA9IgSAAIAAiBIASAAIAAA4IAhAAIAAg4IASAAIAACBg");
	this.shape_24.setTransform(129.975,14.625);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#666666").s().p("AgTA8QgIgFgDgLQgDgJAAgMIAAgtQAAgNADgKQADgKAIgFQAIgFAMAAQAMAAAIAEQAHAFADAIQADAJAAALIAAAKIgRAAIAAgJIgBgMQgBgGgDgDQgDgDgIAAQgGAAgEADQgDAEgBAGIgBANIAAAzQAAAJABAGQACAGAEADQADACAFgBQAIAAADgCQADgEABgFIABgOIAAgKIARAAIAAAKQAAAMgDAJQgDAJgHAFQgHAFgNAAQgMAAgIgGg");
	this.shape_25.setTransform(121.425,14.65);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#666666").s().p("AgYBBIAAiBIAxAAIAAAOIgfAAIAAAqIAZAAIAAAMIgZAAIAAAwIAfAAIAAANg");
	this.shape_26.setTransform(110.675,14.625);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#666666").s().p("AgQA9QgHgFgFgIQgDgJAAgLIAQgEQAAAHACAGQABAGAEAFQAEADAGAAQAHAAAEgDQADgEAAgIQAAgIgEgFIgKgLIgVgTQgHgFgDgHQgCgHAAgKQgBgOAJgHQAIgIAOAAQAGAAAHACQAFACAEAEQAEAEADAGQACAGABAJIgQAEQAAgGgCgFQgBgFgEgEQgEgEgFAAQgHABgEAEQgDADAAAHQAAAGACADQACAEAEAEIAVATQAIAGAFAJQAFAJAAAMQAAAJgDAHQgFAHgHAEQgGAEgJAAQgKAAgIgFg");
	this.shape_27.setTransform(103.5,14.65);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#666666").s().p("AATBBIgGghIgZAAIgGAhIgRAAIAbiBIARAAIAbCBgAALATIgLg5IgKA5IAVAAg");
	this.shape_28.setTransform(95.675,14.625);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#666666").s().p("AgYBBIAAiBIAxAAIAAAOIgfAAIAAAqIAZAAIAAAMIgZAAIAAAwIAfAAIAAANg");
	this.shape_29.setTransform(88.775,14.625);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#666666").s().p("AgZBBIAAiBIASAAIAAB0IAhAAIAAANg");
	this.shape_30.setTransform(82.475,14.625);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#666666").s().p("AgfBBIAAiBIAgAAQALAAAHAEQAHAFADAIQADAIAAALQAAAKgEAIQgDAHgHADQgHAEgKAAIgOAAIAAA9gAgNgIIAIAAQAIAAAEgBQAEgCACgEQACgFAAgIIgBgOQgBgFgFgCQgEgCgJAAIgIAAg");
	this.shape_31.setTransform(75.45,14.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol89, new cjs.Rectangle(0,0,237,65.1), null);


(lib.Symbol86 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgJAbQgEgDgBgFQgCgFAAgIIAAgMQAAgHACgGQABgFAEgCQAEgDAFAAQAHAAAEADQADADABAGQACAFAAAIIAAAEIgWAAIAAAMIAAAFIADAEIACABQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAgBIACgDIAAgFIAAgDIAKAAIAAACQAAAJgDAFQgEAFgJAAQgGAAgDgDgAgDgUQAAABAAAAQgBAAAAABQAAAAAAABQgBABAAAAIAAAIIAAADIALAAIAAgFIAAgGIgCgEIgEgBIgDABg");
	this.shape.setTransform(102.575,205.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AATAeIAAgsIgBgGQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBAAAAAAIgFABIgEADIAAABIAAABIAAAtIgJAAIAAgsQAAgEgBgCQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAAAgBAAIgFABIgEADIAAAvIgKAAIAAg6IAKAAIAAAGQADgDADgCQAEgBAEgBQADABABABQADACABAEQADgEAEgCQADgBAEgBQADABADABIADAFQACADAAAEIAAAtg");
	this.shape_1.setTransform(97.075,205.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s().p("AgJAbQgEgDgBgEQgCgFAAgHIAAgQQAAgGACgFQABgFAEgCQAEgDAFAAQAGAAAEADQAEACABAFQACAFAAAGIAAAQQAAAHgCAFQgBAEgEADQgEADgGAAQgFAAgEgDgAgDgTQgCACAAADIAAAGIAAARIAAAGQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABABAAQAAAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgGIAAgRIAAgGQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABg");
	this.shape_2.setTransform(91.525,205.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#666666").s().p("AALApIAAgnIgUAAIAAAnIgMAAIAAhQIAMAAIAAAiIAUAAIAAgiIAKAAIAABQg");
	this.shape_3.setTransform(86.6,204.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#666666").s().p("AgJAbQgEgDgBgFQgCgFAAgIIAAgMQAAgHACgGQABgFAEgCQAEgDAFAAQAHAAAEADQADADABAGQACAFAAAIIAAAEIgWAAIAAAMIAAAFIADAEIACABQABAAAAAAQABAAAAgBQABAAAAAAQAAAAABgBIACgDIAAgFIAAgDIAKAAIAAACQAAAJgDAFQgEAFgJAAQgGAAgDgDgAgDgUQAAABAAAAQgBAAAAABQAAAAAAABQgBABAAAAIAAAIIAAADIALAAIAAgFIAAgGIgCgEIgEgBIgDABg");
	this.shape_4.setTransform(79.475,205.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#666666").s().p("AgEApIAAhQIAJAAIAABQg");
	this.shape_5.setTransform(76.275,204.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#666666").s().p("AgBAoIgFgEIAAAEIgLAAIAAhQIALAAIAAAcQACgDADgBQACgBADAAQAEAAADACQADACACADIABAIIAAAFIAAAOQAAAGgBAGQgBAFgDAEQgDADgGAAQgDAAgBgBgAgCgIIgEACIAAAkIAEABIADABQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAgBIACgFIAAgIIAAgOIAAgGIgCgEQgBgBAAAAQgBAAAAgBQgBAAAAAAQgBAAgBAAIgCABg");
	this.shape_6.setTransform(72.95,204.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#666666").s().p("AgKAcQgDgCgCgDQgBgDAAgEQAAgFACgEQACgEADgCIAHgEIAIgDIAAgEIgBgGIgBgEIgEgBIgDABIgCADIAAAEIAAADIgLAAQAAgKAFgEQAEgFAIAAQAIAAAEAFQADAFAAAIIAAAaIABAFIAAAFIAAAEIgJAAIgBgEIgBgFQgBAEgDADQgCADgEAAQgEAAgCgCgAABACIgDADIgCADIgBAFIABAFQAAABABAAQAAAAABABQAAAAABAAQAAAAABAAIACgBIACgCIACgBIAAgQg");
	this.shape_7.setTransform(68.525,205.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#666666").s().p("AgEApIAAhQIAJAAIAABQg");
	this.shape_8.setTransform(65.325,204.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#666666").s().p("AgFAnIAAg5IALAAIAAA5gAgFgbIAAgLIALAAIAAALg");
	this.shape_9.setTransform(63.05,204.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#666666").s().p("AgKAcQgDgCgCgDQgBgDAAgEQAAgFACgEQACgEADgCIAHgEIAIgDIAAgEIgBgGIgBgEIgEgBIgDABIgCADIAAAEIAAADIgLAAQAAgKAFgEQAEgFAIAAQAIAAAEAFQADAFAAAIIAAAaIABAFIAAAFIAAAEIgJAAIgBgEIgBgFQgBAEgDADQgCADgEAAQgEAAgCgCgAABACIgDADIgCADIgBAFIABAFQAAABABAAQAAAAAAABQABAAABAAQAAAAABAAIACgBIACgCIACgBIAAgQg");
	this.shape_10.setTransform(59.775,205.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#666666").s().p("AgFAdIgMg5IALAAIAGAuIAHguIALAAIgLA5g");
	this.shape_11.setTransform(55.725,205.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#666666").s().p("AAMApIgEgVIgPAAIgEAVIgLAAIARhQIAKAAIASBQgAAHAMIgHgkIgGAkIANAAg");
	this.shape_12.setTransform(51.375,204.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#666666").s().p("AgBAkQgCgCgCgDIgBgHIAAglIgGAAIAAgHIAGAAIAAgRIAKAAIAAARIAJAAIAAAHIgJAAIAAAkIABAFQAAAAAAAAQABABAAAAQABAAABAAQAAAAABAAIACAAIACAAIAAAIIgEAAIgDABQgFAAgCgCg");
	this.shape_13.setTransform(93.525,172.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#666666").s().p("AgJAbQgEgDgBgEQgCgFAAgHIAAgQQAAgGACgFQABgFAEgCQAEgDAFAAQAGAAAEADQAEACABAFQACAFAAAGIAAAQQAAAHgCAFQgBAEgEADQgEADgGAAQgFAAgEgDgAgDgTQgCACAAADIAAAGIAAARIAAAGQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABABAAQAAAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgGIAAgRIAAgGQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABg");
	this.shape_14.setTransform(89.875,173.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#666666").s().p("AgPApIAAhQIALAAIAABIIAUAAIAAAIg");
	this.shape_15.setTransform(86.05,172.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#666666").s().p("AgJAbQgEgDgBgFQgCgFAAgIIAAgMQAAgHACgGQABgFAEgCQAEgDAFAAQAHAAAEADQADADABAGQACAFAAAIIAAAEIgWAAIAAAMIAAAFIADAEIACABQABAAAAAAQABAAAAgBQABAAAAAAQAAAAABgBIACgDIAAgFIAAgDIAKAAIAAACQAAAJgDAFQgEAFgJAAQgGAAgDgDgAgDgUQAAABAAAAQgBAAAAABQAAAAAAABQgBAAAAABIAAAIIAAADIALAAIAAgFIAAgGIgCgEIgEgBIgDABg");
	this.shape_16.setTransform(79.475,173.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#666666").s().p("AgEApIAAhQIAJAAIAABQg");
	this.shape_17.setTransform(76.275,172.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#666666").s().p("AgBAnIgFgDIAAAEIgLAAIAAhQIALAAIAAAcQACgDADgBQACgBADAAQAEAAADACQADACACAEIABAHIAAAFIAAAOQAAAGgBAGQgBAFgDAEQgDADgGAAQgDAAgBgCgAgCgIIgEACIAAAkIAEABIADABQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAgBIACgFIAAgIIAAgOIAAgGIgCgEQgBgBAAAAQgBAAAAgBQgBAAAAAAQgBAAgBAAIgCABg");
	this.shape_18.setTransform(72.95,172.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#666666").s().p("AgKAcQgDgCgCgDQgBgDAAgEQAAgFACgEQACgEADgCIAHgEIAIgDIAAgEIgBgGIgBgEIgEgBIgDABIgCADIAAAEIAAADIgLAAQAAgKAFgEQAEgFAIAAQAIAAAEAFQADAFAAAIIAAAaIABAFIAAAFIAAAEIgJAAIgBgEIgBgFQgBAEgDADQgCADgEAAQgEAAgCgCgAABACIgDADIgCADIgBAFIABAFQAAABABAAQAAAAABABQAAAAABAAQAAAAABAAIACgBIACgCIACgBIAAgQg");
	this.shape_19.setTransform(68.525,173.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#666666").s().p("AgEApIAAhQIAJAAIAABQg");
	this.shape_20.setTransform(65.325,172.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#666666").s().p("AgFAnIAAg5IALAAIAAA5gAgFgbIAAgLIALAAIAAALg");
	this.shape_21.setTransform(63.05,172.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#666666").s().p("AgKAcQgDgCgCgDQgBgDAAgEQAAgFACgEQACgEADgCIAHgEIAIgDIAAgEIgBgGIgBgEIgEgBIgDABIgCADIAAAEIAAADIgLAAQAAgKAFgEQAEgFAIAAQAIAAAEAFQADAFAAAIIAAAaIABAFIAAAFIAAAEIgJAAIgBgEIgBgFQgBAEgDADQgCADgEAAQgEAAgCgCgAABACIgDADIgCADIgBAFIABAFQAAABABAAQAAAAAAABQABAAABAAQAAAAABAAIACgBIACgCIACgBIAAgQg");
	this.shape_22.setTransform(59.775,173.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#666666").s().p("AgFAdIgMg5IALAAIAGAuIAHguIALAAIgLA5g");
	this.shape_23.setTransform(55.725,173.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#666666").s().p("AAMApIgEgVIgPAAIgEAVIgLAAIARhQIAKAAIASBQgAAHAMIgHgkIgGAkIANAAg");
	this.shape_24.setTransform(51.375,172.05);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#6B6B6B").s().p("AAAAPIgaAUIAXhFIAGAAIABAAIAXBFg");
	this.shape_25.setTransform(151.4,20.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#6B6B6B").s().p("AALAoIgTgvIAAAvIgMAAIAAhQIAKAAIATAuIAAguIAMAAIAABQg");
	this.shape_26.setTransform(151.475,29.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#86C1CD").s().p("AhjBkIAAjHIDHAAIAADHg");
	this.shape_27.setTransform(27.3,204.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#F6CB4C").s().p("AhjBkIAAjHIDHAAIAADHg");
	this.shape_28.setTransform(27.3,172.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#7DCEA5").s().p("AhjBkIAAjHIDHAAIAADHg");
	this.shape_29.setTransform(27.3,139.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#B9B092").s().p("AhjBkIAAjHIDHAAIAADHg");
	this.shape_30.setTransform(27.3,71.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#DC954B").s().p("AhjBkIAAjHIDHAAIAADHg");
	this.shape_31.setTransform(27.3,105.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#999999").ss(1,1,1).p("ArAAAIWBAA");
	this.shape_32.setTransform(87.8,46);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#666666").s().p("AgJAbQgEgDgBgFQgCgFAAgIIAAgMQAAgHACgGQABgFAEgCQAEgDAFAAQAHAAAEADQADADABAGQACAFAAAIIAAAEIgWAAIAAAMIAAAFIADAEIACABQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAgBIACgDIAAgFIAAgDIAKAAIAAACQAAAJgDAFQgEAFgJAAQgGAAgDgDgAgDgUQAAABAAAAQgBAAAAABQAAAAAAABQgBAAAAABIAAAIIAAADIALAAIAAgFIAAgGIgCgEIgEgBIgDABg");
	this.shape_33.setTransform(116.875,140.475);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#666666").s().p("AATAeIAAgsIgBgGQgBAAAAgBQgBAAAAAAQAAAAgBAAQgBgBAAAAIgFACQgCABgCADIAAAAIAAABIAAAtIgJAAIAAgsQAAgEgBgCQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAgBgBAAIgFACIgEAEIAAAuIgKAAIAAg6IAKAAIAAAGQADgDADgCQAEgCAEAAQADAAABACQADACABAEQADgEAEgCQADgCAEAAQADABADABIADAFQACADAAAEIAAAtg");
	this.shape_34.setTransform(111.375,140.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#666666").s().p("AgJAbQgEgDgBgEQgCgFAAgHIAAgQQAAgGACgFQABgFAEgCQAEgDAFAAQAGAAAEADQAEACABAFQACAFAAAGIAAAQQAAAHgCAFQgBAEgEADQgEADgGAAQgFAAgEgDgAgDgTQgCACAAADIAAAGIAAARIAAAGQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABABAAQAAAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgGIAAgRIAAgGQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABg");
	this.shape_35.setTransform(105.825,140.475);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#666666").s().p("AALApIAAgmIgVAAIAAAmIgLAAIAAhQIALAAIAAAjIAVAAIAAgjIAKAAIAABQg");
	this.shape_36.setTransform(100.9,139.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#666666").s().p("AAGAdIAAgqIgBgFQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAIgCABIgEADIAAAtIgLAAIAAg5IALAAIAAAGQADgDACgBQAEgCAEAAQADAAACABQACACABADIABAFIAAAug");
	this.shape_37.setTransform(93.725,140.425);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#666666").s().p("AgJAbQgEgDgBgEQgCgFAAgHIAAgQQAAgGACgFQABgFAEgCQAEgDAFAAQAGAAAEADQAEACABAFQACAFAAAGIAAAQQAAAHgCAFQgBAEgEADQgEADgGAAQgFAAgEgDgAgDgTQgCACAAADIAAAGIAAARIAAAGQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABABAAQAAAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgGIAAgRIAAgGQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABg");
	this.shape_38.setTransform(89.375,140.475);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#666666").s().p("AgJAbQgEgDgBgEQgCgFAAgHIAAgQQAAgGACgFQABgFAEgCQAEgDAFAAQAGAAAEADQAEACABAFQACAFAAAGIAAAQQAAAHgCAFQgBAEgEADQgEADgGAAQgFAAgEgDgAgDgTQgCACAAADIAAAGIAAARIAAAGQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABABAAQAAAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgGIAAgRIAAgGQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABg");
	this.shape_39.setTransform(85.125,140.475);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#666666").s().p("AgJAmQgGgDgCgFQgCgFgBgHIALgDIABAIIADAHQADACADAAQAEAAADgCQACgDAAgEQAAgGgCgDIgHgHIgNgLQgDgDgCgEQgCgFgBgGQABgJAEgFQAGgEAJAAIAHABIAGAEQADACABAEIACAJIgJADIgCgHQgBgEgCgCQgCgCgDAAQgEAAgDACQgCADAAAEQAAAEABACQABADADACIANAMQAFADADAGQADAFAAAIQAAAGgCAEQgCAFgFACQgEACgGAAQgGAAgEgDg");
	this.shape_40.setTransform(80.75,139.325);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#666666").s().p("AgLAmIgHgEQgCgCAAgEIABgFIADgEIAEgDIgEgCIgCgEQAAgDACgDIAFgEIgFgFQgCgFAAgGQAAgIACgEQACgFAEgBQADgDAFAAQAEAAADABQADACABADIADgCIAFgEIACgBIACAHIgDABIgEACIgCABIABAFIAAAGQAAAGgBAEQgCAFgDABQgDADgGAAIgCAAIgDgBIgBACIgBACIABACIAEABIAIABQAHAAADAEQADADAAAHQAAAEgCAEQgCADgFACQgEABgGABIgJgBgAgJAUIgCACIAAADQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABQACABAGAAQAFAAACgBQADgCAAgDIgBgCIgCgCIgFgBIgIgCgAgFgdIgCACIgBAFIgBAGIABAEIABAFIACADIADAAIADAAIACgDIABgEIAAgFIAAgGIgBgEIgCgDIgCgBIgEABg");
	this.shape_41.setTransform(74.025,141.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#666666").s().p("AAGAdIAAgqIgBgFQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAIgCABIgEADIAAAtIgLAAIAAg5IALAAIAAAGQADgDACgBQAEgCAEAAQADAAACABQACACABADIABAFIAAAug");
	this.shape_42.setTransform(69.575,140.425);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#666666").s().p("AgFAnIAAg5IAKAAIAAA5gAgFgbIAAgLIAKAAIAAALg");
	this.shape_43.setTransform(66.25,139.475);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#666666").s().p("AATAeIAAgsIgBgGQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAIgFACQgCABgCADIAAAAIAAABIAAAtIgJAAIAAgsQAAgEgBgCQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAgBgBAAIgFACIgEAEIAAAuIgKAAIAAg6IAKAAIAAAGQADgDADgCQAEgCAEAAQADAAABACQADACABAEQADgEAEgCQADgCAEAAQADABADABIADAFQACADAAAEIAAAtg");
	this.shape_44.setTransform(61.725,140.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#666666").s().p("AgJAbQgEgDgBgEQgCgFAAgHIAAgQQAAgGACgFQABgFAEgCQAEgDAFAAQAGAAAEADQAEACABAFQACAFAAAGIAAAQQAAAHgCAFQgBAEgEADQgEADgGAAQgFAAgEgDgAgDgTQgCACAAADIAAAGIAAARIAAAGQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABABAAQAAAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgGIAAgRIAAgGQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABg");
	this.shape_45.setTransform(56.175,140.475);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#666666").s().p("AgMAmQgFgEgBgGQgCgGAAgIIAAgbQAAgJACgGQABgGAFgDQAFgDAIAAQAHAAAEACQAFADACAFQACAGAAAHIAAAGIgKAAIAAgFIgBgIQgBgEgBgCQgDgCgEAAQgEAAgDACQgCACAAAEIgBAJIAAAfIABAKQABADACACQADABADAAQAEAAADgCQABgCABgDIABgJIAAgGIAKAAIAAAGQAAAIgCAFQgCAGgEADQgFADgHAAQgIAAgFgDg");
	this.shape_46.setTransform(51.5,139.325);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#666666").s().p("AgBAkQgCgCgCgDIgBgHIAAglIgGAAIAAgHIAGAAIAAgRIAKAAIAAARIAJAAIAAAHIgJAAIAAAkIABAFQAAAAAAAAQABABAAAAQABAAABAAQAAAAABAAIACAAIACAAIAAAIIgEAAIgDABQgFAAgCgCg");
	this.shape_47.setTransform(107.825,105.525);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#666666").s().p("AgJAbQgEgDgBgEQgCgFAAgHIAAgQQAAgGACgFQABgFAEgCQAEgDAFAAQAGAAAEADQAEACABAFQACAFAAAGIAAAQQAAAHgCAFQgBAEgEADQgEADgGAAQgFAAgEgDgAgDgTQgCACAAADIAAAGIAAARIAAAGQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABABAAQAAAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgGIAAgRIAAgGQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABg");
	this.shape_48.setTransform(104.175,106.325);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#666666").s().p("AgPAoIAAhQIALAAIAABIIAUAAIAAAIg");
	this.shape_49.setTransform(100.35,105.15);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#666666").s().p("AAGAdIAAgqIgBgFQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAIgCABIgEADIAAAtIgLAAIAAg5IALAAIAAAGQADgDACgBQAEgCAEAAQADAAACABQACACABADIABAFIAAAug");
	this.shape_50.setTransform(93.725,106.275);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#666666").s().p("AgJAbQgEgDgBgEQgCgFAAgHIAAgQQAAgGACgFQABgFAEgCQAEgDAFAAQAGAAAEADQAEACABAFQACAFAAAGIAAAQQAAAHgCAFQgBAEgEADQgEADgGAAQgFAAgEgDgAgDgTQgCACAAADIAAAGIAAARIAAAGQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABABAAQAAAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgGIAAgRIAAgGQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABg");
	this.shape_51.setTransform(89.375,106.325);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#666666").s().p("AgJAbQgEgDgBgEQgCgFAAgHIAAgQQAAgGACgFQABgFAEgCQAEgDAFAAQAGAAAEADQAEACABAFQACAFAAAGIAAAQQAAAHgCAFQgBAEgEADQgEADgGAAQgFAAgEgDgAgDgTQgCACAAADIAAAGIAAARIAAAGQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABABAAQAAAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgGIAAgRIAAgGQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABg");
	this.shape_52.setTransform(85.125,106.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#666666").s().p("AgJAmQgGgDgCgFQgCgFgBgHIALgDIABAIIADAHQADACADAAQAEAAADgCQACgDAAgEQAAgGgCgDIgHgHIgNgLQgDgDgCgEQgCgFgBgGQABgJAEgFQAGgEAJAAIAHABIAGAEQADACABAEIACAJIgJADIgCgHQgBgEgCgCQgCgCgDAAQgEAAgDACQgCADAAAEQAAAEABACQABADADACIANAMQAFADADAGQADAFAAAIQAAAGgCAEQgCAFgFACQgEACgGAAQgGAAgEgDg");
	this.shape_53.setTransform(80.75,105.175);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#666666").s().p("AgLAlIgHgDQgCgDAAgEIABgEIADgEIAEgCIgEgDIgCgEQAAgDACgCIAFgFIgFgGQgCgDAAgIQAAgGACgFQACgFAEgCQADgCAFAAQAEAAADABQADACABAEIADgEIAFgCIACgBIACAHIgDABIgEABIgCABIABAFIAAAGQAAAFgBAFQgCAEgDACQgDADgGAAIgCgBIgDAAIgBACIgBADIABABIAEABIAIABQAHABADADQADADAAAHQAAAFgCADQgCADgFACQgEABgGAAIgJgBgAgJAUIgCACIAAADQAAABAAAAQAAABAAAAQABABAAAAQAAAAABAAQACACAGAAQAFAAACgCQADgBAAgCIgBgEIgCgCIgFgBIgIAAgAgFgdIgCADIgBAEIgBAFIABAGIABADIACADIADACIADgCIACgCIABgEIAAgGIAAgFIgBgEIgCgDIgCAAIgEAAg");
	this.shape_54.setTransform(74.025,107.15);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#666666").s().p("AAGAdIAAgqIgBgFQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAIgCABIgEADIAAAtIgLAAIAAg5IALAAIAAAGQADgDACgBQAEgCAEAAQADAAACABQACACABADIABAFIAAAug");
	this.shape_55.setTransform(69.575,106.275);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#666666").s().p("AgFAnIAAg5IAKAAIAAA5gAgFgbIAAgLIAKAAIAAALg");
	this.shape_56.setTransform(66.25,105.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#666666").s().p("AATAdIAAgrIgBgGQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBAAAAAAIgFABIgEADIAAABIAAABIAAAsIgJAAIAAgrQAAgEgBgCQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAAAgBAAIgFABIgEADIAAAuIgKAAIAAg4IAKAAIAAAFQADgDADgCQAEgBAEAAQADAAABABQADACABAEQADgEAEgCQADgBAEAAQADgBADACIADAEQACADAAAFIAAAsg");
	this.shape_57.setTransform(61.725,106.25);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#666666").s().p("AgJAbQgEgDgBgEQgCgFAAgHIAAgQQAAgGACgFQABgFAEgCQAEgDAFAAQAGAAAEADQAEACABAFQACAFAAAGIAAAQQAAAHgCAFQgBAEgEADQgEADgGAAQgFAAgEgDgAgDgTQgCACAAADIAAAGIAAARIAAAGQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABABAAQAAAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgGIAAgRIAAgGQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABg");
	this.shape_58.setTransform(56.175,106.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#666666").s().p("AgMAmQgFgEgBgGQgCgGAAgIIAAgbQAAgJACgGQABgGAFgDQAFgDAIAAQAHAAAEACQAFADACAFQACAGAAAHIAAAGIgKAAIAAgFIgBgIQgBgEgBgCQgDgCgEAAQgEAAgDACQgCACAAAEIgBAJIAAAfIABAKQABADACACQADABADAAQAEAAADgCQABgCABgDIABgJIAAgGIAKAAIAAAGQAAAIgCAFQgCAGgEADQgFADgHAAQgIAAgFgDg");
	this.shape_59.setTransform(51.5,105.175);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#666666").s().p("AgOAkIAAgIIAGAAIADgCIACgCIgBgEIgCgHIgLgwIAKAAIAHAqIAIgqIAKAAIgNA8QgBAEgDADQgBACgDABIgJABg");
	this.shape_60.setTransform(122,73.475);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#666666").s().p("AgBAkQgCgCgCgDIgBgHIAAglIgGAAIAAgHIAGAAIAAgRIAKAAIAAARIAJAAIAAAHIgJAAIAAAkIABAFQAAAAAAAAQABABAAAAQABAAABAAQAAAAABAAIACAAIACAAIAAAIIgEAAIgDABQgFAAgCgCg");
	this.shape_61.setTransform(118.525,71.975);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#666666").s().p("AgMAdIAAg5IALAAIAAAJQACgGAEgBQADgCADAAIABAAIABAAIAAAMIgDgBIgDgBQgBAAAAAAQgBAAgBABQAAAAgBAAQAAAAgBABQgCABgBADIAAApg");
	this.shape_62.setTransform(115.625,72.725);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#666666").s().p("AgJAbQgEgDgBgFQgCgFAAgIIAAgMQAAgHACgGQABgFAEgCQAEgDAFAAQAHAAAEADQADADABAGQACAFAAAIIAAAEIgWAAIAAAMIAAAFIADAEIACABQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAgBIACgDIAAgFIAAgDIAKAAIAAACQAAAJgDAFQgEAFgJAAQgGAAgDgDgAgDgUQAAABAAAAQgBAAAAABQAAAAAAABQgBABAAAAIAAAIIAAADIALAAIAAgFIAAgGIgCgEIgEgBIgDABg");
	this.shape_63.setTransform(111.725,72.775);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#666666").s().p("AgRAnIAAhMIALAAIAAAFIAEgEQACgCAEAAQAFAAACADQADACABADIACAIIAAAGIAAAOQAAAFgBAFQgBAGgDADQgDAEgGAAQgDAAgCgCIgEgEIAAAYgAgDgdIgDADIAAAkIADABIAEABQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAgBIABgFIAAgHIAAgOIAAgHQAAgDgBgCQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAgBAAIgDAAg");
	this.shape_64.setTransform(107.45,73.675);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#666666").s().p("AgJAbQgEgDgBgEQgCgFAAgHIAAgQQAAgGACgFQABgFAEgCQAEgDAFAAQAGAAAEADQAEACABAFQACAFAAAGIAAAQQAAAHgCAFQgBAEgEADQgEADgGAAQgFAAgEgDgAgDgTQgCACAAADIAAAGIAAARIAAAGQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABABAAQAAAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgGIAAgRIAAgGQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABg");
	this.shape_65.setTransform(103.025,72.775);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#666666").s().p("AgMAdIAAg5IALAAIAAAJQACgGAEgBQADgCADAAIABAAIABAAIAAAMIgDgBIgDgBQgBAAAAAAQgBAAgBABQAAAAgBAAQAAAAgBABQgCABgBADIAAApg");
	this.shape_66.setTransform(99.525,72.725);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#666666").s().p("AgTApIAAhQIATAAQAHAAAEACQAFADACAFQACAFAAAHQAAAGgDAFQgCAEgEACQgEADgHAAIgIAAIAAAmgAgIgFIAGAAIAGgBQADAAABgDIABgIIgBgJQgBgDgCgBQgDgCgEAAIgGAAg");
	this.shape_67.setTransform(95.55,71.6);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#666666").s().p("AgJAbQgEgDgBgFQgCgFAAgIIAAgMQAAgHACgGQABgFAEgCQAEgDAFAAQAHAAAEADQADADABAGQACAFAAAIIAAAEIgWAAIAAAMIAAAFIADAEIACABQABAAAAAAQABAAAAgBQABAAAAAAQAAAAABgBIACgDIAAgFIAAgDIAKAAIAAACQAAAJgDAFQgEAFgJAAQgGAAgDgDgAgDgUQAAABAAAAQgBAAAAABQAAAAAAABQgBABAAAAIAAAIIAAADIALAAIAAgFIAAgGIgCgEIgEgBIgDABg");
	this.shape_68.setTransform(88.575,72.775);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#666666").s().p("AgEApIAAhQIAJAAIAABQg");
	this.shape_69.setTransform(85.375,71.6);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#666666").s().p("AgBAnIgFgDIAAAEIgLAAIAAhQIALAAIAAAcQACgDADgBQACgBADAAQAEAAADACQADACACADIABAIIAAAFIAAAOQABAGgCAGQgBAFgDAEQgDADgGAAQgDAAgBgCgAgCgIIgEACIAAAkIAEABIADABQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAgBIACgFIAAgIIAAgOIAAgGIgCgEQgBgBAAAAQAAAAgBgBQgBAAAAAAQgBAAgBAAIgCABg");
	this.shape_70.setTransform(82.05,71.65);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#666666").s().p("AgKAcQgDgCgCgDQgBgDAAgEQAAgFACgEQACgEADgCIAHgEIAIgDIAAgEIgBgGIgBgEIgEgBIgDABIgCADIAAAEIAAADIgLAAQAAgKAFgEQAEgFAIAAQAIAAAEAFQADAFAAAIIAAAaIABAFIAAAFIAAAEIgJAAIgBgEIgBgFQgBAEgDADQgCADgEAAQgEAAgCgCgAABACIgDADIgCADIgBAFIABAFQAAABABAAQAAAAABABQAAAAABAAQAAAAABAAIACgBIACgCIACgBIAAgQg");
	this.shape_71.setTransform(77.625,72.775);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#666666").s().p("AgEApIAAhQIAJAAIAABQg");
	this.shape_72.setTransform(74.425,71.6);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#666666").s().p("AgEAnIAAg5IAKAAIAAA5gAgEgbIAAgLIAKAAIAAALg");
	this.shape_73.setTransform(72.15,71.775);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#666666").s().p("AgKAcQgDgCgCgDQgBgDAAgEQAAgFACgEQACgEADgCIAHgEIAIgDIAAgEIgBgGIgBgEIgEgBIgDABIgCADIAAAEIAAADIgLAAQAAgKAFgEQAEgFAIAAQAIAAAEAFQADAFAAAIIAAAaIABAFIAAAFIAAAEIgJAAIgBgEIgBgFQgBAEgDADQgCADgEAAQgEAAgCgCgAABACIgDADIgCADIgBAFIABAFQAAABABAAQAAAAABABQAAAAABAAQAAAAABAAIACgBIACgCIACgBIAAgQg");
	this.shape_74.setTransform(68.875,72.775);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#666666").s().p("AgFAdIgMg5IALAAIAGAuIAHguIALAAIgLA5g");
	this.shape_75.setTransform(64.825,72.75);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#666666").s().p("AgKAcQgDgCgCgDQgBgDAAgEQAAgFACgEQACgEADgCIAHgEIAIgDIAAgEIgBgGIgBgEIgEgBIgDABIgCADIAAAEIAAADIgLAAQAAgKAFgEQAEgFAIAAQAIAAAEAFQADAFAAAIIAAAaIABAFIAAAFIAAAEIgJAAIgBgEIgBgFQgBAEgDADQgCADgEAAQgEAAgCgCgAABACIgDADIgCADIgBAFIABAFQAAABABAAQAAAAABABQAAAAABAAQAAAAABAAIACgBIACgCIACgBIAAgQg");
	this.shape_76.setTransform(60.775,72.775);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#666666").s().p("AAGAdIAAgqIgBgFQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAIgCABIgEADIAAAtIgLAAIAAg5IALAAIAAAGQADgDACgBQAEgCAEAAQADAAACABQACACABADIABAFIAAAug");
	this.shape_77.setTransform(56.525,72.725);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#666666").s().p("AgNAmQgEgEgBgGQgCgHgBgIIAAg1IAMAAIAAA1IAAAJQABAFACADQADACADAAQAFAAADgCQACgDAAgFIABgJIAAg1IAKAAIAAA1QABAIgCAHQgCAGgFAEQgEADgJAAQgHAAgGgDg");
	this.shape_78.setTransform(51.6,71.65);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#666666").s().p("AgHBBIAAguIgdhTIARAAIATA/IAUg/IARAAIgdBTIAAAug");
	this.shape_79.setTransform(36.45,24.875);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#666666").s().p("AgYBBIAAiBIAxAAIAAAOIgfAAIAAAqIAZAAIAAAMIgZAAIAAAwIAfAAIAAANg");
	this.shape_80.setTransform(29.625,24.875);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#666666").s().p("AARBBIgYg9IgJAPIAAAuIgSAAIAAiBIASAAIAAA9IAeg9IAQAAIgZA5IAeBIg");
	this.shape_81.setTransform(22.65,24.875);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("At3Q9MAAAgh5IbuAAMAAAAh5g");
	this.shape_82.setTransform(88.75,116.9684,1,1.0781);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol86, new cjs.Rectangle(0,0,177.5,233.9), null);


(lib.Symbol85 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ar3HRIAAuhIXvAAIAAOhg");
	this.shape.setTransform(75.95,46.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol85, new cjs.Rectangle(0,0,151.9,93), null);


(lib.Symbol83 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AnqILIBum4II2psIAzAaICsCOIBSAnIo4Njg");
	this.shape.setTransform(46.35,53.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.7,0,98.2,107.5);


(lib.Symbol82 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AmXGjII2tmIBxA2IBfAqIApAhIhpJ7IhZA9IgUBOg");
	this.shape.setTransform(36.675,45.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.1,0,81.6,90.4);


(lib.Symbol81 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AANAwIgSgtIgGALIAAAiIgOAAIAAhfIAOAAIAAAtIAVgtIANAAIgTAqIAWA1g");
	this.shape.setTransform(37.225,11.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AgOAtQgGgEgCgHQgDgIAAgIIAAgiQAAgKADgHQACgIAGgEQAGgDAJAAQAJAAAFADQAFADADAHQADAFgBAKIAAAHIgMAAIAAgHIgBgJQgBgFgCgBQgCgDgGAAQgFAAgDADQgCACgBAFIgBAKIAAAlIABAMQACAFADABQADACADAAQAGAAACgDQACgCABgFIABgKIAAgHIAMAAIAAAHQAAAJgBAHQgDAHgFAEQgFAEgKAAQgJgBgGgEg");
	this.shape_1.setTransform(30.85,11.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s().p("AAOAwIgEgYIgTAAIgFAYIgMAAIAUhfIAMAAIAVBfgAAIAPIgIgrIgHArIAPAAg");
	this.shape_2.setTransform(24.825,11.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#666666").s().p("AgYAwIAAhfIAWAAQAFAAAFABQAFABADADQAEADACAFQABAFAAAFQAAAHgBAEQgCAEgEADQgDACgEABQAGABAEACQADAEABAFQACAFAAAHQAAAGgBAFQgBAGgDADQgEADgEACQgFACgGAAgAgLAnIAJAAQAIAAAEgEQADgEAAgKQgBgGgBgFQgCgDgEgCQgDgDgFAAIgIAAgAgLgHIAIAAQAFAAADgCQADgCACgDQABgDAAgHQAAgGgCgDQgCgDgEgBIgKAAIgEAAg");
	this.shape_3.setTransform(18.9,11.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// Layer_2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#999999").ss(1,1,1).p("AkXhsIIvAAIAADZIovAAg");
	this.shape_4.setTransform(28.025,10.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AkXBsIAAjYIIvAAIAADYg");
	this.shape_5.setTransform(28.025,10.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,58.1,23.7);


(lib.Symbol80 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AjuErIjAhkIgCgCIgBgDIACgDIIpnoIADgBIACAAIEwBzIACACIABADIgBADIkiFIIhYCGIgBACIgDABIkfAJIAAAAIgCAAg");
	this.shape.setTransform(42.8972,29.3963);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,86.8,59.8);


(lib.Symbol79 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ah5FdIgvgZIgBAAIjJi/IgBgDIgeiDIAAgDIACgDIJ2lVIADgBIADABIACADIAlBjIB9CEIABADIAAACIgCADIoEHGIgDABIAAABIgCgBg");
	this.shape.setTransform(39.7086,34.451);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,80.4,69.9);


(lib.Symbol78 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AhbFiIgCgCIhGhLIgBgBIgmhlIAAAAIh8knQAAgBAAAAQAAgBgBAAQAAgBABAAQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAIH5jhIACgBIADABIABADIAsBsIBeBrIACADIgCADImcHgIgCACIgBAAIgCAAg");
	this.shape.setTransform(32.2489,34.8716);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,65.5,70.8);


(lib.Symbol77 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("AA+FPIkshxIgjAfQgBAAAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBAAAAgBIg3g5IgCgDIACgEIG+oIIACgCIADAAIDTAqIADACIABADIAGB4IAAACIhUDbIAAABIi5EWIgDACIgCAAIgBAAg");
	this.shape.setTransform(33.2508,33.0233);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,67.5,67.1);


(lib.Symbol76 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AFZGsIjRgqIggAnIgDABIgCAAIgDgBIhfhsIgBgBIgrhtIh5j/ImDh3IgDgDIgBgDIADgDIFKjlIABgBIBvgVIACAAICNApIDxA6IB6AGIADABICbChIABACIAAADIjMJEIgDACIgCABIgBAAg");
	this.shape.setTransform(55.0506,42.3007);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,111.1,85.6);


(lib.Symbol75 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AE7EzIgCgBIgCgCIgYg9IgogxIhLgPInfAuIAAAAIhegEIgCgBIiihEIgBgBIkBipIgCgCIAAgDIACgDIADgBIEZATIDzgaIErheIExixIACgBIACAAIGFB5IACABIABACIB6EAIABADIgBACIgCACIn6DhIgCABIgBAAg");
	this.shape.setTransform(82.1745,30.1749);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,165.4,61.4);


(lib.Symbol74 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AjkGEIgCgCIgCgCIgNhlIgQgWIgygJIgWAFIhGA8IgCABIgEAAIgCgDIAAgDQAliPB7oAIABgDIADgBIGCgoIABAAIBOARIADACIApAyIAAABICWFnIAAADIgDADIp6FTIgCABIgBAAg");
	this.shape.setTransform(33.849,38.3003);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.3,-0.5,82.39999999999999,77.6);


(lib.Symbol73 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AlmElIgCgCIAAgDIA1liIACgDID+jfQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAICuANIACABIACACIDnIPIAAADIgBACIgDACIrIAlIAAAAIgDgBg");
	this.shape.setTransform(35.6181,28.8995);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,72.3,58.8);


(lib.Symbol72 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ah5FhIgCgCIjnoPIAAgCIAAgCIAthcIACgBIACgBIEXhPIADAAIADACIF2KiIABADIgCADIgDABInUAYIAAAAIgDgBg");
	this.shape.setTransform(35.0017,34.9041);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,71,70.8);


(lib.Symbol71 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#444444").s().p("AANHaIgCgCIl3qiQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBIBTgvIDFjXIADgCIADABIACACIG3MSIAAADIgBACIgCACIlZCXIgCAAIgCAAg");
	this.shape.setTransform(36.0536,46.8961);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,73.1,94.8);


(lib.Symbol70 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABMHaQAAAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAAAIm3sTIgBgDIACgDIACgBIEYhMIAzhJIADgCIADAAIADADIGEKXIAAADIgBADIjgDyIgCABIg7AgIgCAAIgCAAg");
	this.shape.setTransform(36.1505,46.8997);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,73.3,94.8);


(lib.Symbol69 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAdHjQAAgBgBAAQAAAAgBAAQAAgBAAAAQgBAAAAgBImEqXIgBgDIABgCIAthQIABgBIDzjTIACgCIADABIACACIGtL7QAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQAAAAgBABIlIC/IgDABIgBAAg");
	this.shape.setTransform(35.8714,47.7696);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,72.8,96.6);


(lib.Symbol68 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AA4HVIgCgCImtr7IAAgDIAAgDIACgBIFSilIAEAAIADACIGTLFIABADIgCADIk5DbIgCABIgBAAIgCAAg");
	this.shape.setTransform(37.1286,46.4262);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,75.3,93.9);


(lib.Symbol67 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AhjGoIgCgCImVrFIAAgCIABgDIBMhmIABgBIACgBIIVgbIACAAIACACIGLHMIABACIAAADIgCADIpXF5IgDAAIgCAAg");
	this.shape.setTransform(50.2265,41.925);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,101.5,84.9);


(lib.Symbol66 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABSDJIlyh2IgCgCIgBgDIABgDIDKkSIADgBIADAAIBSApIEfgJIADABIACADIgBADIjMFoIgCACIgCAAIgBAAg");
	this.shape.setTransform(28.7275,19.655);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,58.5,40.3);


(lib.Symbol65 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAmDlIkbimIgCgCIAAgDIABgDIDmkZIADgCIACAAIADABIBkBcICaBRIACACIAAADIgBADIjKERIgDACIgBAAIgDAAg");
	this.shape.setTransform(24.3235,22.4243);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,49.7,45.9);


(lib.Symbol64 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAiFKIkZiCQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIAlhQIg6ikIAAgDIACgDIBdhKIDFjEIAEgCIAagBIABAAIA2AHIABABIACABIATAbIABACIARCCIAAAAIAaBnIBiBhIACAEIgBADIjnEbIgCABIgCAAIgCAAg");
	this.shape.setTransform(26.701,32.5197);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,54.4,66.1);


(lib.Symbol63 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AEAFuIqjkNIgCgCIgBgDIACgDIEUjlIAAABIDNjhIADgCIADABIChBEIBjADIBbgHIADABIACACIAAADIihKSIgBACIgCACIgBAAIgCgBg");
	this.shape.setTransform(41.7947,36.1773);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,84.6,73.4);


(lib.Symbol62 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AhUFdQgBAAAAAAQgBgBAAAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIAEgyIgehnIhrh6IAAAAIipjTIgBgCIgKhFIAAgCIABgCIBJhYIACgBIBjgoIACgBICEAMIAAAAIDqAzIACABIEBCqIACACIABADIgCADIjUDlIAAABIkODgIgDABIAAAAg");
	this.shape.setTransform(39.7757,34.3753);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,80.6,69.8);


(lib.Symbol61 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AosFUIg0gCIgDgBIgBgDIAAgDIDcnZIALhhIABgDIAEgBIJtAGIAxgNIBWg6IABAAIBKgfIADAAIBBAOIADABIA1BCIABABIAhBLIAAADIgCADIk7DZIAAAAIkxCyIgBAAIkwBhIgBABIjwAXIAAAAIgBAAg");
	this.shape.setTransform(60.843,33.4949);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,122.7,68);


(lib.Symbol60 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AEHFkIjngRIAAAAIjqg0IiDgLIgDgBIgBgCIihkNIAAgCIAAgCIADgCIMNlhIACAAIADABIDOCBIACACIAAADIgJBdIgBACIjdHeIgCACIgDABIAAAAg");
	this.shape.setTransform(49.4261,35.1001);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,99.9,71.2);


(lib.Symbol59 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AHzEBIg0g9IhBgOIhLAfIhVA5Ig0AOIptgGIjPiCIR5ngIAtHSIB+CrIhuAUIgQAIg");
	this.shape.setTransform(65.85,33.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,131.7,66.5);


(lib.Symbol58 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AnJHtIhngmIgCgBIhFhCIgBgBIgphnIAAgCIADh5IgSgxIgBgDIACgCICTiyIABgBILBkjIEjiAIADgBIADACICjCcIABACIA/CvIAAADIgCADIgDABIilAMIg5AWIhDBVIgNBeIATCGIAAABIgMBFIgBACIgsAvIgDACIn8CpIgCAAIkfAGIAAAAIgCAAg");
	this.shape.setTransform(68.4708,48.7733);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,138,98.6);


(lib.Symbol57 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("AkqIoIgCgBIgCgCIg+iuIiiicIgCgCIABgDIGTsQIADgDIADAAIADACIKDP7IABACIgBADIgCACIiGBEIgBABIisApIgBAAIjCAJg");
	this.shape.setTransform(52.3965,56.9024);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,105.8,114.8);


(lib.Symbol56 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAvKjIgCgCIqEv6IgBgEIAGgoIAAi/IABgCIAphaIACgCIADgBIADABIBnBBIABACIBUC4ICLB7IGYB9IACABIAvAyIABACIAuBmIBKA8IBZAcIACABICTBqIACADIAAADIgCACIisCNIAAgBIjeDlIAAAAIiZB6IgDABIAAABIgCgBg");
	this.shape.setTransform(59.5718,67.0513);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,120.2,135.1);


(lib.Symbol55 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AicChIgCgCIgBgCIgejhIABgDIACgDID2hWIAEAAIADADIB6D1IABADIgCADIgCABIlTBCIgBAAIgCAAg");
	this.shape.setTransform(18.4758,15.5999);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,38,32.2);


(lib.Symbol54 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ah4CMIgCgCIgBgCIgRi7IAAgCIAZhTIADgCIADgBIBFANICSgGIADACIACADIAeDhQAAAAAAABQAAAAAAAAQgBABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAIj+AlIAAAAIgCAAg");
	this.shape.setTransform(13.5767,13.5226);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,28.2,28.1);


(lib.Symbol53 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AilBsIgSg8ICbkGICLBdIBJAcIgZBTIARC7Ij4Amg");
	this.shape.setTransform(18.425,21.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,36.9,43);


(lib.Symbol52 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABODEIk5hKIgCgBIgCgDIABgDICIjpIACgCIB2g4IAdgOIAIgDIACgBIABAAQAGgCABAEICsB1IACADIAAADIicEGIgCACIgCABIgBAAg");
	this.shape.setTransform(23.4537,19.0547);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,47.9,39.2);


(lib.Symbol51 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ag+DSIgDgCIiVijIgBgDIAAiUIgVgnIAAgCIABgDIAog5IACgCIADAAIE4BKIADABIABACQAQA4gCABIACAAIABACIBdBpIABADIAAADIgCACIklCpIgDABIgBAAg");
	this.shape.setTransform(23.2258,20.5029);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,47.5,42);


(lib.Symbol50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ai7CgIgDgCIh0iMIgCgDIABgDIACgCIEmioIADgBIADABIE4EMIACADIAAADIgCACIgDABIm9ATIgrAVIgCABIgBAAg");
	this.shape.setTransform(30.372,15.4786);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,61.8,32);


(lib.Symbol49 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABpEHIgDgCImYnaIgCgDIABgDIACgCIAsgWIACAAIG+gTIADABIA9AoIAAAAQA/AtgGAPQgEALgGBHIgGBFIAAAAIgMCJIgBADIhRBbIgCABIhYAoIgCABIgBAAg");
	this.shape.setTransform(30.3637,25.8029);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,61.8,52.6);


(lib.Symbol48 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AhMDeIgDgBIjIjSIgCgCIABgDIABgCIEXjgQAAgBAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABABQAAAAABAAIETFBIABADIgBAEIgDABIkABFIhfAsIgCAAIgBAAg");
	this.shape.setTransform(27.6707,21.726);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,56.4,44.5);


(lib.Symbol47 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AhDCuIgDgCIiQiZIgBgCIAAgDIACgCIFBi4IAEgBIADACIBkBxIABACIAAADIgCACIkVDgIgDABIgBAAg");
	this.shape.setTransform(21.1017,16.8743);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,43.2,34.8);


(lib.Symbol46 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AhyDIIgDgBIhehoIgBgDIABgDIDzkfIACgBIADAAIADABICsDOIABACIgBADIgCACIlBC5IgCABIgBgBg");
	this.shape.setTransform(20.8017,19.5535);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,42.6,40.1);


(lib.Symbol45 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ag0DsIgCgBIiNigIgBgCIAAgDIBhjKIABgCIBhhkIACgBIADABIA/AlIABABICACJIABAEIgBADIjzEfIgCABIgCAAIgBAAg");
	this.shape.setTransform(19.2232,23.1214);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,39.5,47.3);


(lib.Symbol44 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAZDAIgDgBIjRjUIgBgBIgig+IgBgDIABgDIADgBIExhkIADgBIACABIA3ArIBLAdIACACIABADIgCADIhfBjIhhDKIgCACIgDABIAAgBg");
	this.shape.setTransform(21.8743,18.7507);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,44.8,38.5);


(lib.Symbol43 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AinCYIgCgDIgyhnIgBgDIACgDIEyi+IAEgBIB9AaIADACIABADIgCADIgDACIhFAIIgdAyIAAA2IAbAwIABADIgBACIgDACIkxBkIgCAAIgCAAg");
	this.shape.setTransform(21.5763,14.694);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,44.2,30.4);


(lib.Symbol42 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("Ai4DUIgBgBIhDh4IgBgEIACgDIFxknIADgBIACAAIAQAGIAAABIAvAcIACACIAyBLIABACIAPCMIAAADIgDACIgDABIh7gZIkvC9IgDABIgDgBg");
	this.shape.setTransform(20.4232,20.7963);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5,-0.5,50.9,42.6);


(lib.Symbol39 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#424242").s().p("AiGHJIgCgCIhrjaIgBgDIBxpnIABgBIAohIIACgCIADgBIADACIA8BFIAAABIAuBqIABABIAfBkIAAACIgBACIgbAvIgYBVIARA7IA0A0IBYA0IgBgBIBRAhIADADIAAADIgCADIlzEnIgCABIAAAAIgDgBg");
	this.shape.setTransform(23.9519,45.2968);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,48.9,91.6);


(lib.Symbol38 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAuDjIhggpIAAAAIhXgyIgBgBIg2g1IgBgCIgTg+IAAgDIAZhXIABgBIAbgvIACgCICthoQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABAAAAIC+EoIABAEIgCADIifCTIgDABIgBAAIgCAAg");
	this.shape.setTransform(20.7793,22.2306);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,42.6,45.5);


(lib.Symbol37 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AATDIIgCgCIi8koIgBgDIAAgDIACgBICehdIAEgBIADACICxEDIABACIAAADIgCACIgiAVIhwBtIgDABIAAAAIgDAAg");
	this.shape.setTransform(16.8252,19.523);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,34.7,40.1);


(lib.Symbol36 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("AADDCIgCgCIiykCIgBgDIABgCIACgCIBOgvIAAgBIBVgoIABgBIBzgZIAAAAIBFgGIADAAIACACIABADIAAFNIgBADIgDACIipAsIgBAAIgCAAg");
	this.shape.setTransform(17.3741,18.9232);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,35.8,38.9);


(lib.Symbol35 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AiUB9IAAlOIB6AcIBgA/IBOBPIhLD5g");
	this.shape.setTransform(14.85,20.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,29.7,41.9);


(lib.Symbol34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ACWCyIkuhhQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBABAAIBLj5IACgCIADgBIADABIBJA0IA+ATIACABIABACIBbESIgBAEIgCACIgCAAIgCAAg");
	this.shape.setTransform(15.173,17.3492);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,31.4,35.7);


(lib.Symbol33 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAnC5IiYgpIgCgBIgCgCIhakSIAAgDIACgDIACgBIBEgDIBSgQIBGgYIACgBIADABIC4CKQABAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQAAAAgBABIijDdIgCACIgCAAIgBAAg");
	this.shape.setTransform(20.3277,17.9713);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,41.7,37);


(lib.Symbol32 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AGLD+Ii3iIIhFAYIgBAAIhRAQIgBAAIhEADIgBAAIg/gTIgBgBIhLg1IgBAAIhOhOIhihAIh2gYIgDgBIgBgDIgIibIABgDIACgCIACgBIOFgLIACABIACACIABACIg1HzIgCADIgDACIAAAAIgDgBg");
	this.shape.setTransform(22.4755,25.3504);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.1,-0.1,91.19999999999999,51);


(lib.Symbol31 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AkODyIgCgBIgCgCIgfhkIguhpIg8hDIgBgDIABgEICWjHIACgCIACgBIKRAGIAEACIABADIAICaIgBAEIgEABIhFAHIh1AaIhQAmIAAAAImZDzIgCABIgBgBg");
	this.shape.setTransform(40.7751,23.7503);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,82.6,48.5);


(lib.Symbol30 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnHjmIh0FEIEQCJIB0gJIBkg+IBgh3IBkhUIBwgcICEANIBBA1ICWjIg");
	this.shape.setTransform(57.225,23.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("Ao7BeIB0lEIQDAZIiWDIIhBg1IiEgNIhwAcIhkBUIhgB3IhkA+Ih0AJg");
	this.shape_1.setTransform(57.225,23.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,116.5,48.3);


(lib.Symbol29copy15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("Anya0QkkkgpKlBQkligjrhnIhdgzQCJkOA2hUQAIgNAYg+QAehRAVgwQBTi8BkhfQD5jwEmkGQJMoODlh0QDkh1EohhQCUgwBmgaIQ7jsICFAVInDJTIgQFxIENDsQEXD3AwA9QAwA9AJBrQAEA0gFApIipFdIgKGvIhnC+I9vCLQkxIWgDAAIAAgBg");
	this.shape.setTransform(179.7816,0.3028);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20,-171.3,399.6,343.3);


(lib.Symbol29copy13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("AFLI8QjJhPk9jQQighoh3hYIh7hEQDhj6AUgZQAUgaCAiQQB9iNAagiIDqANIEWJ+QBCCVAgBiQAYBHABAaQADBSgxA9QgqA1hEAAQguAAg5gYg");
	this.shape.setTransform(84.7116,62.6501);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(25.7,3.1,117.99999999999999,119.2);


(lib.Symbol29copy12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(50,50,50,0.2)").s().p("Ap3DUQgBgBg0iCQBJiHA2hUIBRiPQBCh1AcgmIQrhGIg2GdIkBAKIoXJOg");
	this.shape.setTransform(101.15,50.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(32.7,0.1,137,101.30000000000001);


(lib.Symbol29copy11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("AAHF9IlfhiQhojhgqhhQgMgbAhi1QAii2gJgcIM0g4Ij7GQIFBIcIAwBXg");
	this.shape.setTransform(107.14,52.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(57.8,1.1,98.8,102.9);


(lib.Symbol29copy10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("ABEFMInBicQgQg9gWhJQgsiQgig6QgKgYhNikQhDiQgLghINQDoICFDNICaEUICIDlIA2Btg");
	this.shape.setTransform(111.275,58.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(45,5.6,132.6,105.2);


(lib.Symbol29copy9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("AEKF5Iw4lIQg4hJhFg7QAnhOBkiTQBiiQAJAEQD2CDB6hfQAqghAVg3QAQgqgDgdIQjFlIBmCzIAcD4IhKCGIgSB9IANBkg");
	this.shape.setTransform(91.475,53.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-3.5,188,114.3);


(lib.Symbol29copy8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(50,50,50,0.2)").s().p("ADZGZIsBkWIgLhYQgJhFgHhGQgSi6hoiYIgRgXIgSgaQgjgzgogwIgXgeIaFIMIiiHZQAMAnATAiQAOAeAXAZIAMBkg");
	this.shape.setTransform(102.25,49.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(18.8,-11.8,167,122.6);


(lib.Symbol29copy7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(50,50,50,0.2)").s().p("ACeFtItQmWIAIglQAxjmAAjtIgBgOIgBgWIgCgTIgBgHIUxHtQgEA7gDA6QgKD8gCD9QAAAyAGAyg");
	this.shape.setTransform(109.725,50.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(40.7,-10.7,138.10000000000002,121.5);


(lib.Symbol29copy6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(50,50,50,0.2)").s().p("Ao9GfQgbh7gZh9QgShagPhYIgDgVQgNhJgShFQg6jZBXjPIAFgIIAFgGIVZKHQhLBCg/BLQgrA0ghA8IgKATIgLASIv2Egg");
	this.shape.setTransform(111.177,50.525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(39.6,-10.7,143.20000000000002,122.5);


(lib.Symbol29copy5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(72,211,182,0.498)").s().p("Am6HBQgBAAhbjfIhtkKQERiUAmgVIMPm3IALC1IC2M9Iv2Efg");
	this.shape.setTransform(94.875,46.8999);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(72,211,182,0.647)").s().p("Am6HAIjJnpIRHpfIAICKIABAVQAAAKADAKQBZGgBbGeIv2Efg");
	this.shape_1.setTransform(94.875,46.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(30.5,-18,128.8,129.8);


(lib.Symbol29copy4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(50,50,50,0.2)").s().p("ApGGXIhtkLQERiSAmgWIQwpZIglEJIhJGVIjuB+IsaG7IgoAUQgBAAhbjfg");
	this.shape.setTransform(99.6503,28.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(30.5,-34.2,138.4,126);


(lib.Symbol29copy3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("AqyGbIg3kkICKhDICnhPQBQgmB4hLIOGoLIBGD4IAOFBImwDkIsaG6IikBYQgBAAgtj9g");
	this.shape.setTransform(102.625,32.1499);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(28.1,-34.2,149.1,132.8);


(lib.Symbol29copy2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("AqwFnIg3klICJgtQCPgvAXgOQCUhZA0gYIK4m6ICPCvICRDjInbEcIoZEqQkICUgBgBIh1A8QgCAAgkjtg");
	this.shape.setTransform(102.425,37.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(28.1,-22.2,148.70000000000002,119.3);


(lib.Symbol29copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#444444").s().p("AooIGQgBgBgpiVIg8i+IiCnxIH5qmQAPAvARA/QAiB/AJBTQALBsAgBiQAQAxANAcIB7BuIFHDrIHTGAImrEgImSDyIlrCFg");
	this.shape.setTransform(89.525,43.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(11,-56,157.1,199.6);


(lib.Symbol29 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("AEII7IthlDIgDgCQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIDOqDIABgCIADgCIADABIEPCJIBxgJIBig+IAAAAIBgh2IAAAAIBkhVIACgBIBxgcIACAAICDAMIADACIBBA1IACACIgBAEIgnBHIhxJmIAAACIi2F6IgDADIgBAAIgCAAg");
	this.shape.setTransform(60.027,56.605);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,121.1,114.2);


(lib.Symbol28 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ai6ONIgCgBInelxIgCgDIgHgjIABgCIHb17IACgCIACgCIADABINhFCIACACIABACIgBADIicFTIAAC+IAAABIgGApIAAABImUMQIgCACIkiCAIgCABIgBAAg");
	this.shape.setTransform(67.0725,90.372);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,135.2,181.8);


(lib.Symbol27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#323232").s().p("AywNcIhriJIgMhPIB6imIADhXIiciTIAGiDIB3kTIUtrJIGEARINfGBIqxR8I5VDJg");
	this.shape.setTransform(135.125,87.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270.3,175.1);


(lib.Symbol26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ajyk9IAsAjIBBAlICfAPICHArIBmBaIA1B0IAgBYIggA8IhpA5IjvAoIiyAIIh9AjIgQALg");
	this.shape.setTransform(144.6625,65.3375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(109.9,33.6,69.6,63.6);


(lib.Symbol25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Al1P6IgDgBIgBgDIkI+JIAAgDIACgCIACgBIJNguIA1gUIABAAICWgeIABAAIGvA8IABABIAyAZIADACIAAADIgBADIo3JrIhRFPIjBKkIAAABIioE0IgCACIgCAAIgBAAg");
	this.shape.setTransform(63.7267,101.2996);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,128.5,203.6);


(lib.Symbol24copy2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ArCIrIAZgcIhIlBIAQhCICokzIClo2IP5ArIBDBmIBKAvInfAhQgBAAgNGWIgLFjIt9Hhg");
	this.shape.setTransform(75.375,84.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,11,150.8,146.8);


(lib.Symbol24copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AmTAqQANmWABABIHegiIA2AiICEA/IBaBLIAyCiIgKD0ImEgPImvDoIALlkg");
	this.shape.setTransform(141.875,69.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(100.4,30.2,83,79.5);


(lib.Symbol23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#323232").s().p("ApnUqIgDgBIoTtJIgBgEIACgDIBXhXICIj1IATkFIAAgCIBUi9IgWh9IlQk0IgBgCIAAgCIAGjSIABgDIEZlnIADgCIACAAIDIAvIFngQIKpAcIHUggIADACIACADIEDeOIAAABIgLA8IBIFBIAAACIgBACIgXAaIA9CwIAAADIgCACIgCABI7/BVIAAAAIgCgBg");
	this.shape.setTransform(117.7248,131.8029);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(5));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,236.5,264.6);


(lib.Symbol22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABJIMItemBIAKj0IgyijIhahLIiFg+Ih/hQIhEhnIAUhNIBphJIB9gjICygIIDwgnIBpg6IAgg8IgghXIFegNIQmKHIAKEIIC2FzIAPDtIBnCZIgFE2IhJBfg");
	this.shape.setTransform(124.775,103.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,249.6,207.8);


(lib.Symbol21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#323232").s().p("AFFIGIuosVIhThSIA3gQICZAcICggoIDoACIAtgUIArhDIgFg8IgziIIClC3IBaBdIAoCiIHOMYIg8Bfg");
	this.shape.setTransform(69.525,66.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,139.1,132.7);


(lib.Symbol20copy2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AhdA9IleANIg1h1IhmhaIh9gqIiqgPIg/gmIhVhDIB4gPICHhGIBEhsIAyhrIBQg1IDjgjIAzgZQJvGpABgBQE9BlABgBIGaHxIgSAVIg3F3g");
	this.shape.setTransform(104.1875,131.3875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,60.6,208.4,141.70000000000002);


(lib.Symbol20copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ACqE8QAAABk9hlQAAABpwmoIAkgSIBEjKIBhhfIAAgcIg8jBIAjhFIBJBIIOzMfIE2CRIAlD9IhNDhIhyCDImbnxg");
	this.shape.setTransform(150.325,81.3375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(73.1,0,154.5,162.7);


(lib.Symbol19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ApgnGIDNDjIBaBdIAoCiIHOMYIGki5IgKllIm4xJg");
	this.shape.setTransform(60.875,82);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AkRAcIgoiiIhahdIjNjjIL/ltIG4RIIAKFmImkC5g");
	this.shape_1.setTransform(60.875,82);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,123.8,166);


(lib.Symbol18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ADIIpIiYgcIg1APIgDAAIgDgCIiJjyIh7hrIAAAAImbjDIgCgCIgBgDIABgDICyj0IAPhxIABgCIBBhUIACgCIBQglIABgBIETg3IADABIACACIGbJTIDvCEIABABIAnAsIABACIAzCIIABABIAFA8IgBADIgrBEIgCABIgtAUIgCABIjogDIifApIgCAAIAAAAg");
	this.shape.setTransform(68.0757,54.7709);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,137.2,110.6);


(lib.Symbol17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AloMTIhhgrIgDgCIAAgDIACgDIADgBICtgNICbhnIAMhAIgUg/ImbmtIgCgCIgeiLIABgEIAthfIABgBIErkcIAiikIABgBIBFicIABgCIADgBIADAAIGaDFIABABIB9BrIABABICJDzIABACIgBADIgiBEIA8C+IAAABIAAAcQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAIhgBeIhDDKQgBAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAIhXAqIgCABIjiAiIhOA0IgxBqIAAAAIhIB0IgCABIiCA/IgCAAIh4APIgBAAIgCAAg");
	this.shape.setTransform(57.3711,78.2251);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,115.8,157.5);


(lib.Symbol16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(68,68,68,0.2)").s().p("AgtIoIgCAAIjwiFIgCgBImcpVIgBgBIgYhLIAAgDIABgCIADgBIQ9kiIADAAIACACIFmLZQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQAAABgBAAIr+FtIgDAAIAAAAg");
	this.shape.setTransform(72.2051,54.7531);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,145.4,110.5);


(lib.Symbol15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AA6PeIhjgyImsg7IiWAdIg1AUIgEAAIgCgCIgBgEIBVrdIjllRIgBgDIg6nOIAAAAIgBgHIAAAAIgBgKIAAgDIACgCIACgBIC+gPIAAAAIADABIABAAIABACIAWgHQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAgBIgEAAIBDgXIDTiNIABAAIAegVIACgBIEEgsIAAAAIAbgIIACgBIEuheIADAAIA5AIIABAAIA4AHIABAAIADABIAHABIACABICaBXIABABIClBpIAAAAICRBmIABACIAsBUIABAAIAKASIABADIAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAIgCgCQhpAIhqALQjYAUgMAHIAAAAQgNAIhFA/IAAAAIhCA8IAADRIF5CWIADADIAAADIgJArIgCACIiMCSIifCLIgsBdIAeCJICYCeIACACIgBADIgBADImyEeIgDAAIAAAAIgCAAgAtppxIAAABIAEgBg");
	this.shape.setTransform(88.0222,98.5241);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,177.1,198.1);


(lib.Symbol14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABnMiIk6ibIkrgoIgBAAIjDhQIgDgCIAAgEIHC0iIACgDIADgBIKdgFIADABIACAEIA8HeIDlFSIABAEIhVLfIgBADIgDABIoDApIAAAAIgDgBg");
	this.shape.setTransform(70.5274,79.7758);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,142.1,160.6);


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AmuDcIg3gPIgCgBIgBgCIgjhBIgBgCIABgCIAjg9IABgBIA8gtIAAAAIB6hNIgBAAIBdhMIAdhYIACgDIADgBIADABIFdDqIFdCRIACABIABADIgBADIgDACIhaAeIgBAAIi9APIqeAFIgBAAg");
	this.shape.setTransform(52,21.4996);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,105,44);


(lib.Symbol12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AskP7IgCgDIov66IAAgDIABgDIADgBQAJgBDGgHIDEgHIAAAAID6AcIDogoIAAAAICgAAIACAAIDmA2IA7goICnj6IACgCIB4goIADAAIA2AHQA7AJgBAOQAAAJAfBXIAfBXIE0E8IGDCkIABABICMCAIBXBDQABAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQABABgBAAQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBAAI1kDOIEyJ8IAAADIgBACIgCACIw9EiIgCAAIgCAAgAUFh3IBAgJIhKg5g");
	this.shape.setTransform(136.154,101.3986);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,273.3,203.8);


(lib.Symbol11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABrRZQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBIgKhPIg2hnIlIjYIgCgDIAAgEIBrjaImf45QAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABABIDGB5IBHADICfgqIABgBICpgMIADABIACACIJHcFIAAADIgBACIgCACIkTA3IhOAkIhABSIgOBxIgBACIgwA8QAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgBAAIgDgBg");
	this.shape.setTransform(59.2756,110.9052);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,119.6,222.8);


(lib.Symbol10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Aj4OcIgCgDIiUjwIgBgCIgrn2IAAAAIg8vqIABgDIACgCIADgBIBrAFICdgPIEMhSIACAAIAtAFIADABIACADIGfY4IgBADIhrDfIgCACIgCAAIgDAAIiGhNIh7gRIl4BwIgBAAIgCAAg");
	this.shape.setTransform(49.7713,91.9005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,100.6,184.8);


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AERPpIgDgCImKoAIgBgBIiRk+Il3tlIAAgDIABgDIADgBIB/gUIBRg7IACgBIELgXICPhFIBEhqIADgCIAogMIADAAIEsBuIACABIABADIA8PqIAoH1ICWDvIAAADIgBADIgDACIjWAjIiXBmIgDABIgBgBg");
	this.shape.setTransform(64.1237,99.6522);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,129.3,200.3);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(102,204,255,0.498)").s().p("AnIFoIgEgBIgBgDIgokJIAAgCIBfm8IACgDIADgBIDIAZICgAPIACABIDRBfIABABIBkBeIB3BGIABAAIBLA3IABADIAjBtIAAADIgeBaIgBACIhuBaIgBABIhpBBIgCAAg");
	this.shape.setTransform(49.7461,35.5237);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(102,204,255,0.647)").s().p("AnIFoIgEgBIgBgDIgokJIAAgCIBfm8IACgDIADgBIDIAZICgAPIACABIDRBfIABABIBkBeIB3BGIABAAIBLA3IABADIAjBtIAAADIgeBaIgBACIhuBaIgBABIhpBBIgCAAg");
	this.shape_1.setTransform(49.7461,35.5237);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,100.5,72.1);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(102,204,255,0.498)").s().p("ANBOXIlliRIgBgBIlUjuIgCgCIgbhnIi+h8IgBgBIhlhkIjFhWIj9ggIgDgBIgBgCIkjs+IgBgDIACgDIACgBICcgoIABAAIEYAjIA6gKIDWiVIADgBIAoAAIABAAIC9BBIACABIABACIF3NlICRE/IGLH+IABADIgBACIgBADIhdA+IgCABIgBAAIgCAAg");
	this.shape.setTransform(92.7716,91.4025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(102,204,255,0.647)").s().p("ANBOXIlliRIgBgBIlUjuIgCgCIgbhnIi+h8IgBgBIhlhkIjFhWIj9ggIgDgBIgBgCIkjs+IgBgDIACgDIACgBICcgoIABAAIEYAjIA6gKIDWiVIADgBIAoAAIABAAIC9BBIACABIABACIF3NlICRE/IGLH+IABADIgBACIgBADIhdA+IgCABIgBAAIgCAAg");
	this.shape_1.setTransform(92.7716,91.4025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,186.6,183.8);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AE/LzIpwjrIgCgCIgthBIgBgBIhPiaIh8hAIgBgCIgagoIhOhOIhegaIgDgBIgBgDIgVlwIABgDIACgCINInRIADAAILGAAIADABIACACIAAADIgCADIg7AsIgiA5IAhA8IA1APIACABIACADIgBACInCUjIgBACIgCABIgBAAIgCAAg");
	this.shape.setTransform(77.5749,75.0286);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,156.2,151.1);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AnJDUICvskICrgFIGAAFIC5APIhfG9IAoEJItJHRg");
	this.shape.setTransform(45.775,59.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,91.6,119.6);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AhZNVIgDgCIgCgCIh9qIIAAABIg1ifIhgjjIgBAAIhFh4QgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAAAgBICphjIBDiNIABgBIA+g/IACgBIBogjIB3hLICHheIABgBIBVgZIABAAIB9gKIADAAIACADIABADIivMlIAFCOIAjJiQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAgBABIg2AFIhYAnIhBBAIgBABIhVAjIgCABg");
	this.shape.setTransform(43.5064,85.2494);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,88,171.5);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAWJpIikgPIgBAAIkOhGIgDgCIgBgDIBGxaQABAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAABAAQAAgBABAAIBeAFIDNAAIBsgdIADAAIADACIBGB4IAAAAICHFAIAAABIAeCHIBuJDIAAADIgCADIgDAAIgYAAIh9AUIABAAIhpAZIgBAAIiHAZIAAABIgBgBg");
	this.shape.setTransform(41.2517,61.2512);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,83.5,123.5);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#424242").s().p("AFFJEIi5gKIgBAAIj5goIAAAAIiMgoIgCgBIhfhQIgCgCIgjhzIAAAAIgjheIgmgmIg5gPIhfAFIhjAZQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBIAAgCIgKgBIAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAABAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAIAKhEIABgCIAog3IACgCIBygnIBKhEIAJglIAAhQIABgDIACgCID1haIAAAAIEchfIAAAAIEThuIAAAAID6hLIABAAIBfgUIADABIA8AeIACACIABACIhBRGIgCAEIgDABIhzAFIjhAUIAAAAIAAAAg");
	this.shape.setTransform(73.0228,57.4962);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,-0.5,146.9,116);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,0,0.176)").s().p("AA3H2IgSgDQgIgBgDgCQgHgDgEgIIgDgGIAAgIIAAgEIAKgKIAEgGIACgIIABgEQgBgDgEgGIgJgKIgKgJIAAgBIABgQIADgEIACgEIABgCIADgEIABgCIAEgEIACgFIABgDQAAgBAAAAQAAgBgBAAQAAgBgBAAQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgBAAAAABIgBAAIgEAAQgPACg6AAIhIAEQg9ADg6gBIhNhuIAZgdIALgyIALgXIgBgVIg0gqIACgeIAjgnIgCAAIAEgDIAGgFIAHgBIAzABIAXgBIARABQBSAIAsgGIAOgCIADgCIAFABQAEACADAAQAFgBAAgDQAAgDgEgCQgFgDgGgBIgIgCIgFAAIgJgCIgRgCIgKAAIgDAAQg1gXg3gMQgLgCgGgDIgHgDIAAAAIgJgJIgGgOQgCgEgKgIIgNgHIgIgEIgEgEQgJgMgRABQgOACgNALIgCADIgFABIgLAEQgBgCgFAAIgMAAIgGAAIgLACIgYAHIgBAAQgNgBgUgEQgdgFgMAAQgMgBgYADQgYACgMgBIgXgCIgagDQgEgBgEACIghgUIgBgBIgFgNIgCgKQgDgHgIgCIgFAAQgIAAgRADIgCABIgHgEIAAgCQgBgHADgCIAEgCIAXgMQAFgDABgDIABgFIAAgJIAMgEIAQgIIAKgCIADgBIAEgCQAigGAMgEIAygTIAFgCIACgBIASgDIAAAAIACgBIAEAAQAJAAAOABIAWACQAVAAAUgIQAPgFAHgKQAHgPAHgFQABgCANgFQAOgFAJgKQADACAEgCIAFgEIANgHIAIgFIAHgBIAlgBIAiAAQArAAAVADQAIAAABgDIgBgEIgVg1QgKgagEgUIACgBQAKgDANABIAcAEQARABALgFQAEgCANgLIAFgDIAGgBIARAEQALADAGAAQAMABAMgIIACgBIABAAIAigEIAWgEIAIgEIAGgGIAIgLIAGABQAQABAYAHQAQAFAJAAQAGABAMgDIAsgMIAEADIAOAHIAOAHQAKADASgCIA4gHIAtgCIAMgBIAAAAIAPADIAEAAIAEgBQARABALgGIABAAIAFABQAbAAAKACIANAEIAQABQAIAAADgBQAEgCAEgFQAKgLAQgWIACgCIANABIAPABIAAAGQABASALAMIARANIASANIANAIQAGADAOADQAOADAYAKIABACQAGAIAEADIAIAGQACACANAGQACACgxAGIipAWIBrC5IBDCSIABAvIgPAGIgHADIgGADQgMADgFACIgIAGIgHACQgFACgHAHIgDAFIABADIAAAEIAAAGIAEAMIABAGIABABIgCAEIgDALIgFAKQgCAEgJAHQgIAFgCAFIgDAIQgFAUgBAKIgBAoQgBAGACADQABADAEAEIACABIAAACQAAADAFAHIADAJQADAHAIANIACANIACAMQAAAHACADIAGAHIAKALIgBAHIAAAeIgCAJIgHAHIgEAEIgzgUQg6gbg5gTIgGgBQgCABgEAHIgFAHIgGAHQgEAEgCAIIgBAFIgCABIgGAHIgKAMIglA8IgYAhIgCADIhyAIQg8AJhLAIIgKABIgEAAgAitlGIgHgVIAAACIAIATIgBAAgAjSmyIACgBIAAADIACAJg");
	this.shape.setTransform(65.4664,55.3958);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.5,0,142,105.6);


(lib.buttontwo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,0,0.176)").s().p("Az4RLIACgnIAOgLQAZgSAvgpIAtgoIALACQAQACATAAQAVABAGgLQABgCABgIQABgGACgDQAEgHAPgCQBkgOAxgpQAWgSAcgmIAcgmQAEACAGgBQAHgBAPgGQAbgLAggFQAZgFAJgGQAJgGAJgQIAohBIAQgaQAGgBAFgFIALgNQAXgcAvgSIAogPQAYgIAPgIQAUgLAggXQAVgPAMgMIARgDQARgFAVgDIAogDIBTgFIAvgDIAGAAQADAGAIAHQAOAPApA2QAiAsAaAVIAiAbIACABIAEAGIAHAIQAAASgEAHQgDAHgLAKQgFAGgCAFQg4AegjAUQhAAkgwAlQgGAAgHACQgKAEgPAJQgrAcgOANQgPAOgaAeIgFAEIgkAVQgqAXgeANIgZALQgOAHgKAGQgPALgXAZIg/BEQgSAUgMAHQgIAFgPAEIgYAIQgJAEgSAMQgSALgKAEIgUAJQgIAGgCAGIgJAAQkAAZkCgHQgNAAgIADQAMgyAFhAgA30MtQghgBgTgKQgkgUgJhDQgGgoAIgdQAQg7BGgkIAygZQAagMAbgIQAmgMBOggIAegJQAYgIACgFQAAgDgLgJQgLgIgLgFQhBgcgpgiIgegaQgTgQgNgJIgUgMIAFgLQBNjOCNmhIBZkHQAYhJAHggIAFgcQAEgQAEgLIACgFIRqAHQAAANgCASIgFAjIgCAtIgCBkIgJALIgwBKIgPAaIgZgDQgYgEgugPQiLgtg6gXQgVgIgKAFQgEADgDADQgHgCgIAAQgjABgmApIgdAgQgSASgRAIIgLAHQgGAEgCAFQgFALANANIAKAJIAKAJQAIALABAVIACAiQABAIADAGIgHgCQgKgEgLAHQgKAGgEALQgHAVAQAVQAJANAYAPQALAHAIADQAMACAIgGQAJgIgDgRIgIgZIAAgKQAGgHAGgNIArhdQAIgSAIgHQAIgHAOgEQASgHATgDQALgDAIABQAMACAQAJQAQAKAmAbQAiAZAVALQAkAVAeACQAWABAmgJQAvgNAZgTIAjgQQACALADAJIAuBmIABAGIgzAOQgwAPgVAEQguALhWAHIgzAEQgQABgJAEQgGADgDAGQgDAGABAGQADALAMADIAIABQAEAGAGAFQAOANAZAPIAGAHQAEAFAIAFIANAIIAWATIAHAIIAlAiQgCAJAAAMIABAxQgBAbgFAUQgGAYgNAQQgKAMgVAMQgpAWg4AKQgkAGg/AEIgkgSQgEgDgFgCIgCAAIgEgDIABgEQABgHgDgGQgGgLgOgFQAGgMgSgRQgLgLhGg6QgygpgYggQgJgMgVgjQgSgegOgPQgJgLgbgaQgYgXgMgPQgRgYgNgoQgOgvgIgXQgIgagRABQgIABgKAMQgQAWgOAnIgYBAIgTAoQgMAYgFAQIgDAMIgFAGQgFAHACAHQADAIALAGIAUAKQALAHAGAQIAKAdQAOAkAwAgQA6AmBCAOQApAJAIADQAbAKAMASQAEAFAEAJIAHAQQAPAeAmAWQAOAJAZAJIAGAJQAOASAcAZQhAAqg/BFQgvA0gNAMQg7A1hNATQgSAEgGAEQgHAFgDAGQhmAPhpgSQg3gKgUABQgtABgYAYQgJALgCAKQgBAMAHAGQgHAXACAmQADAfgGAPQgGAOgSAOQgaAXglAMQgYAIg7AIIhnARQg2AIgpAAIgJAAgAlsD4IAIgBIgGACIgCgBgARpA3QhVgUgygWQgTgIhGgmQhIgphPgkIgCgBIAFgYQAGgjgKgbIgGgSQgDgKACgIQACgHAKgLQAUgRASgKQAOgIAHgGQAKgKgBgLQgDgPgfgIQh3gbhvgxQgUgKgGgIQgFgFgDgJIgGgQQgIgVggglIgyg6QgagegHgTQgLgcAJgfQAJgfAZgRIAIgFQAEACAEgBQAHgBAEgHQAEgGgBgIQAAgJgLgRIgvhKQCTgzEJh8QEYiCCagxIAAAAQgFAXAGAtQAGAxAFAYQAIAoAMAeQALAaAPANQANAMAVAGQALAEAcAFQAiAHBYAXQApAKATANQALAGAMAMIAVAVIASARQgEAFgEAGQgFAIgFAZQgNA3gjBXQgTAvgFAWIgFAgIgEAfQgLBAgxBIQgSAZgcAiIgwA5QhkB4hMCIIgfA5IgCAFIghgHg");
	this.shape.setTransform(243.4042,499.975);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,405.9,621.3);


(lib.Symbol91copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_9 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(9).call(this.frame_9).wait(1));

	// Layer_1
	this.instance = new lib.Tween2copy("synched",0);
	this.instance.setTransform(37.6,5.55);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:46.1,alpha:1},9,cjs.Ease.get(1)).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88.4,-1,177.2,13.2);


(lib.Symbol91 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_9 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(9).call(this.frame_9).wait(1));

	// Layer_1
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(37.6,5.55);
	this.instance.alpha = 0;

	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(46.1,5.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},9).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,x:46.1,alpha:1},9,cjs.Ease.get(1)).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5,-1,93.8,13.2);


(lib.Symbol90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_5 = function() {
		this.stop();
		
		
		
		
		this.button_3.addEventListener("click", fl_ClickToGoToAndStopAtFrame_7.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_7()
		{
			this.parent.gotoAndStop(0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(5).call(this.frame_5).wait(1));

	// Layer_1
	this.button_3 = new lib.Symbol81();
	this.button_3.name = "button_3";
	this.button_3.setTransform(-0.7,8.15,1,1,0,0,0,18.8,8);
	this.button_3.alpha = 0;
	new cjs.ButtonHelper(this.button_3, 0, 1, 2, false, new lib.Symbol81(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button_3).to({x:18.8,alpha:1},5,cjs.Ease.get(1)).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.5,-0.8,77.6,23.7);


(lib.Symbol88 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_18 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(18).call(this.frame_18).wait(1));

	// Layer_1
	this.instance = new lib.Symbol89();
	this.instance.setTransform(118.5,58.95,1,1,0,0,0,118.5,32.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(7).to({_off:false},0).to({y:45.95,alpha:1},11,cjs.Ease.get(0.99)).wait(1));

	// Layer_2
	this.instance_1 = new lib.Symbol85();
	this.instance_1.setTransform(180.5,180,1,1,0,0,0,139,154);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:154,alpha:1},6,cjs.Ease.get(0.53)).wait(13));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,237,119);


// stage content:
(lib.RECOVER_map_dec_2021 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,1,2,3];
	// timeline functions:
	this.frame_0 = function() {
		/* Click to Go to Frame and Stop
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		
		this.movieClip_1.addEventListener("click", fl_ClickToGoToAndStopAtFrame_3.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_3()
		{
			this.gotoAndStop(1);
		}
		this.movieClip_2.addEventListener("click", fl_ClickToGoToAndStopAtFrame_4.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_4()
		{
			this.gotoAndStop(2);
		}
		
		this.movieClip_3.addEventListener("click", fl_ClickToGoToAndStopAtFrame_5.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_5()
		{
			this.gotoAndStop(3);
		}
		
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
		
		/*
		this.lot61.addEventListener("click", fl_ClickToGoToWebPage_2);
		
		function fl_ClickToGoToWebPage_2() {
			window.open("https://blackberrymtn.s3.amazonaws.com/assets/pdfs/Lot61.pdf", "_blank");
		}
		*/
		/*
		this.lot32.addEventListener("click", fl_ClickToGoToWebPage_3);
		
		function fl_ClickToGoToWebPage_3() {
			window.open("pdfs/Lot32.pdf", "_blank");
		}
		
		
		this.lot55.addEventListener("click", fl_ClickToGoToWebPage_4);
		
		function fl_ClickToGoToWebPage_4() {
			window.open("pdfs/Lot55.pdf", "_blank");
		}
		
		this.lot56.addEventListener("click", fl_ClickToGoToWebPage_5);
		
		function fl_ClickToGoToWebPage_5() {
			window.open("pdfs/Lot56.pdf", "_blank");
		}
		*/
	}
	this.frame_2 = function() {
		this.stop();
		
		this.lotc22.addEventListener("click", fl_ClickToGoToWebPage_lotc22);
		/*
		function fl_ClickToGoToWebPage_lotc22() {
			window.open("https://blackberrymtn.s3.amazonaws.com/assets/pdfs/BMTN_324PlumleafRd.pdf", "_blank");
		}
		
		this.lotc23.addEventListener("click", fl_ClickToGoToWebPage_lotc23);
		
		function fl_ClickToGoToWebPage_lotc23() {
			window.open("https://blackberrymtn.s3.amazonaws.com/assets/pdfs/318PlumleafRoad.pdf", "_blank");
		}
		*/
		/*
		this.lot22.addEventListener("click", fl_ClickToGoToWebPage_22);
		
		function fl_ClickToGoToWebPage_22() {
			window.open("pdfs/Lot22.pdf", "_blank");
		}
		
		this.lot50.addEventListener("click", fl_ClickToGoToWebPage_50);
		
		function fl_ClickToGoToWebPage_50() {
			window.open("pdfs/Lot50.pdf", "_blank");
		}
		
		
		
		
		this.lotc14.addEventListener("click", fl_ClickToGoToWebPage_c14);
		function fl_ClickToGoToWebPage_c14() {
			window.open("pdfs/Lotc14.pdf", "_blank");
		}
		
		this.lotc21.addEventListener("click", fl_ClickToGoToWebPage_c21);
		function fl_ClickToGoToWebPage_c21() {
			window.open("pdfs/Lotc21.pdf", "_blank");
		}
		*/
	}
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer_1
	this.instance = new lib.Symbol91copy();
	this.instance.setTransform(390.2,340,1,1,30.0004,0,0,41.7,5.6);

	this.movieClip_3 = new lib.Symbol99();
	this.movieClip_3.name = "movieClip_3";
	this.movieClip_3.setTransform(537.45,448.05,1,1,0,0,0,56.6,80.5);
	new cjs.ButtonHelper(this.movieClip_3, 0, 1, 2, false, new lib.Symbol99(), 3);

	this.instance_1 = new lib.Symbol91();
	this.instance_1.setTransform(204.65,325.95,1,1,90,0,0,41.6,5.5);

	this.instance_2 = new lib.Symbol91();
	this.instance_2.setTransform(333,219.95,1,1,0,0,0,41.6,5.5);

	this.instance_3 = new lib.Symbol88();
	this.instance_3.setTransform(202.05,250.05,1,1,0,0,0,118.5,77);

	this.movieClip_2 = new lib.buttontwo();
	this.movieClip_2.name = "movieClip_2";
	this.movieClip_2.setTransform(645.8,408.8,1,1,0,0,0,612.8,386.5);
	new cjs.ButtonHelper(this.movieClip_2, 0, 1, 2, false, new lib.buttontwo(), 3);

	this.movieClip_1 = new lib.Symbol1();
	this.movieClip_1.name = "movieClip_1";
	this.movieClip_1.setTransform(683.45,266.7,3.6722,4.23,0,0,0,65.5,54.5);
	new cjs.ButtonHelper(this.movieClip_1, 0, 1, 2, false, new lib.Symbol1(), 3);

	this.instance_4 = new lib.Symbol94();
	this.instance_4.setTransform(686.4,409.25,1,1,0,0,0,29.9,26.7);
	this.instance_4.alpha = 0.1914;

	this.instance_5 = new lib.Symbol93();
	this.instance_5.setTransform(702.2,280.35,1,1,0,0,0,30,26.9);
	this.instance_5.alpha = 0.1914;

	this.instance_6 = new lib.Symbol90();
	this.instance_6.setTransform(73.1,85.8,1,1,0,0,0,28,11);

	this.instance_7 = new lib.Symbol86();
	this.instance_7.setTransform(216.45,638.2,1,1,0,0,0,88.8,113);

	this.instance_8 = new lib.Symbol20copy();
	this.instance_8.setTransform(809.45,435.3,1,1,0,0,0,113.8,101.1);
	this.instance_8.alpha = 0.1914;

	this.instance_9 = new lib.Symbol24copy();
	this.instance_9.setTransform(633.2,580.25,1,1,0,0,0,91.7,78.9);
	this.instance_9.alpha = 0.1914;

	this.instance_10 = new lib.Symbol83();
	this.instance_10.setTransform(627,457.2,1,1,0,0,0,47.7,51.1);
	this.instance_10.alpha = 0.1914;

	this.instance_11 = new lib.Symbol82();
	this.instance_11.setTransform(661,471.85,1,1,0,0,0,38.8,45.1);
	this.instance_11.alpha = 0.1914;

	this.lot56 = new lib.Symbol27();
	this.lot56.name = "lot56";
	this.lot56.setTransform(675.05,675.3,1,1,0,0,0,135.1,87.5);
	this.lot56.alpha = 0.1914;

	this.instance_12 = new lib.Symbol26();
	this.instance_12.setTransform(668.95,461.1,1,1,0,0,0,89.8,55.5);
	this.instance_12.alpha = 0.1914;

	this.instance_13 = new lib.Symbol25();
	this.instance_13.setTransform(580.4,498.4,1,1,0,0,0,63.7,101.3);
	this.instance_13.alpha = 0.1914;

	this.lot55 = new lib.Symbol24copy2();
	this.lot55.name = "lot55";
	this.lot55.setTransform(633.2,580.25,1,1,0,0,0,91.7,78.9);
	this.lot55.alpha = 0.1914;

	this.instance_14 = new lib.Symbol23();
	this.instance_14.setTransform(434.7,535.75,1,1,0,0,0,117.7,131.8);
	this.instance_14.alpha = 0.1914;

	this.instance_15 = new lib.Symbol22();
	this.instance_15.setTransform(802.95,575.5,1,1,0,0,0,124.8,103.9);
	this.instance_15.alpha = 0.1914;

	this.instance_16 = new lib.Symbol21();
	this.instance_16.setTransform(855.9,369.5,1,1,0,0,0,69.5,66.3);
	this.instance_16.alpha = 0.1914;

	this.instance_17 = new lib.Symbol20copy2();
	this.instance_17.setTransform(809.45,435.2,1,1,0,0,0,113.8,101.1);
	this.instance_17.alpha = 0.1914;

	this.lot61 = new lib.Symbol19();
	this.lot61.name = "lot61";
	this.lot61.setTransform(906.6,344.3,1,1,0,0,0,60.9,82);
	this.lot61.alpha = 0.1914;

	this.instance_18 = new lib.Symbol18();
	this.instance_18.setTransform(787.05,280.6,1,1,0,0,0,68,54.8);
	this.instance_18.alpha = 0.1914;

	this.instance_19 = new lib.Symbol17();
	this.instance_19.setTransform(731.55,357.6,1,1,0,0,0,57.4,78.2);
	this.instance_19.alpha = 0.1914;

	this.instance_20 = new lib.Symbol16();
	this.instance_20.setTransform(850.25,244.1,1,1,0,0,0,72.2,54.8);

	this.instance_21 = new lib.Symbol15();
	this.instance_21.setTransform(643.65,321.05,1,1,0,0,0,88.5,110);
	this.instance_21.alpha = 0.1914;

	this.instance_22 = new lib.Symbol14();
	this.instance_22.setTransform(513.6,326.35,1,1,0,0,0,70.5,79.8);
	this.instance_22.alpha = 0.1914;

	this.instance_23 = new lib.Symbol13();
	this.instance_23.setTransform(531.1,225.55,1,1,0,0,0,52,21.5);
	this.instance_23.alpha = 0.1914;

	this.instance_24 = new lib.Symbol12();
	this.instance_24.setTransform(858.35,116.9,1,1,0,0,0,136.2,101.4);
	this.instance_24.alpha = 0.1914;

	this.instance_25 = new lib.Symbol11();
	this.instance_25.setTransform(721.1,149.9,1,1,0,0,0,59.2,110.9);
	this.instance_25.alpha = 0.1914;

	this.instance_26 = new lib.Symbol10();
	this.instance_26.setTransform(653.65,130.4,1,1,0,0,0,49.8,91.9);
	this.instance_26.alpha = 0.1914;

	this.instance_27 = new lib.Symbol9();
	this.instance_27.setTransform(564.7,136.45,1,1,0,0,0,64.1,99.7);
	this.instance_27.alpha = 0.1914;

	this.instance_28 = new lib.Symbol8();
	this.instance_28.setTransform(463.4,193,1,1,0,0,0,49.8,35.5);
	new cjs.ButtonHelper(this.instance_28, 0, 1, 2, false, new lib.Symbol8(), 3);

	this.instance_29 = new lib.Symbol7();
	this.instance_29.setTransform(499.35,150.9,1,1,0,0,0,92.8,91.4);
	new cjs.ButtonHelper(this.instance_29, 0, 1, 2, false, new lib.Symbol7(), 3);

	this.instance_30 = new lib.Symbol6();
	this.instance_30.setTransform(410.95,303.55,1,1,0,0,0,77.5,75);
	this.instance_30.alpha = 0.1914;

	this.lot32 = new lib.Symbol5();
	this.lot32.name = "lot32";
	this.lot32.setTransform(377.35,215.3,1,1,0,0,0,45.8,59.8);
	this.lot32.alpha = 0.1914;

	this.instance_31 = new lib.Symbol4();
	this.instance_31.setTransform(305.55,241.15,1,1,0,0,0,43.5,85.2);
	this.instance_31.alpha = 0.1914;

	this.instance_32 = new lib.Symbol3();
	this.instance_32.setTransform(255.25,271.65,1,1,0,0,0,41.2,61.2);
	this.instance_32.alpha = 0.1914;

	this.instance_33 = new lib.Symbol2();
	this.instance_33.setTransform(147.55,269.45,1,1,0,0,0,73,57.5);
	this.instance_33.alpha = 0.1914;

	this.instance_34 = new lib.Symbol80();
	this.instance_34.setTransform(869.8,316.65,1,1,0,0,0,42.9,29.4);
	this.instance_34.alpha = 0.1914;

	this.instance_35 = new lib.Symbol79();
	this.instance_35.setTransform(838.9,301.7,1,1,0,0,0,39.7,34.5);
	this.instance_35.alpha = 0.1914;

	this.instance_36 = new lib.Symbol78();
	this.instance_36.setTransform(882.1,249.95,1,1,0,0,0,32.2,34.9);
	this.instance_36.alpha = 0.1914;

	this.instance_37 = new lib.Symbol77();
	this.instance_37.setTransform(906.3,265.65,1,1,0,0,0,33.2,33);

	this.instance_38 = new lib.Symbol76();
	this.instance_38.setTransform(904.45,194.55,1,1,0,0,0,55.1,42.3);
	this.instance_38.alpha = 0.1914;

	this.instance_39 = new lib.Symbol75();
	this.instance_39.setTransform(818.35,207.45,1,1,0,0,0,82.2,30.2);
	this.instance_39.alpha = 0.1914;

	this.instance_40 = new lib.Symbol74();
	this.instance_40.setTransform(825.05,263.1,1,1,0,0,0,37.2,38.3);
	this.instance_40.alpha = 0.1914;

	this.instance_41 = new lib.Symbol73();
	this.instance_41.setTransform(328.2,615.6,1,1,0,0,0,35.6,28.9);
	this.instance_41.alpha = 0.1914;

	this.instance_42 = new lib.Symbol72();
	this.instance_42.setTransform(375.75,605.85,1,1,0,0,0,35,34.9);
	this.instance_42.alpha = 0.1914;

	this.instance_43 = new lib.Symbol71();
	this.instance_43.setTransform(409.3,591.5,1,1,0,0,0,36.1,46.9);
	this.instance_43.alpha = 0.1914;

	this.instance_44 = new lib.Symbol70();
	this.instance_44.setTransform(437.45,576.45,1,1,0,0,0,36.1,46.9);
	this.instance_44.alpha = 0.1914;

	this.instance_45 = new lib.Symbol69();
	this.instance_45.setTransform(470.65,548.25,1,1,0,0,0,35.9,47.8);
	this.instance_45.alpha = 0.1914;

	this.instance_46 = new lib.Symbol68();
	this.instance_46.setTransform(500.6,530.4,1,1,0,0,0,37.1,46.4);
	this.instance_46.alpha = 0.1914;

	this.instance_47 = new lib.Symbol67();
	this.instance_47.setTransform(547.5,513,1,1,0,0,0,50.2,41.9);
	this.instance_47.alpha = 0.1914;

	this.instance_48 = new lib.Symbol66();
	this.instance_48.setTransform(846.15,361.55,1,1,0,0,0,28.7,19.7);
	this.instance_48.alpha = 0.1914;

	this.instance_49 = new lib.Symbol65();
	this.instance_49.setTransform(813.35,346.85,1,1,0,0,0,24.3,22.4);
	this.instance_49.alpha = 0.1914;

	this.instance_50 = new lib.Symbol64();
	this.instance_50.setTransform(785.4,320.15,1,1,0,0,0,26.7,32.5);
	this.instance_50.alpha = 0.1914;

	this.instance_51 = new lib.Symbol63();
	this.instance_51.setTransform(755.45,258.25,1,1,0,0,0,41.8,36.1);
	this.instance_51.alpha = 0.1914;

	this.instance_52 = new lib.Symbol62();
	this.instance_52.setTransform(722.15,233.25,1,1,0,0,0,39.8,34.4);
	this.instance_52.alpha = 0.1914;

	this.instance_53 = new lib.Symbol61();
	this.instance_53.setTransform(820.1,173.55,1,1,0,0,0,60.9,33.5);
	this.instance_53.alpha = 0.1914;

	this.instance_54 = new lib.Symbol60();
	this.instance_54.setTransform(732.85,171.75,1,1,0,0,0,49.4,35.1);
	this.instance_54.alpha = 0.1914;

	this.lot22 = new lib.Symbol59();
	this.lot22.name = "lot22";
	this.lot22.setTransform(827.5,121.95,1,1,0,0,0,65.8,33.4);
	this.lot22.alpha = 0.1914;

	this.instance_55 = new lib.Symbol58();
	this.instance_55.setTransform(283.3,503.1,1,1,0,0,0,68.5,48.8);
	this.instance_55.alpha = 0.1914;

	this.instance_56 = new lib.Symbol57();
	this.instance_56.setTransform(381.6,432.7,1,1,0,0,0,52.4,56.9);

	this.instance_57 = new lib.Symbol56();
	this.instance_57.setTransform(429.15,410.65,1,1,0,0,0,59.6,67);
	this.instance_57.alpha = 0.1914;

	this.instance_58 = new lib.Symbol55();
	this.instance_58.setTransform(586.65,302.05,1,1,0,0,0,18.4,15.6);
	this.instance_58.alpha = 0.1914;

	this.instance_59 = new lib.Symbol54();
	this.instance_59.setTransform(557.65,307.8,1,1,0,0,0,13.6,13.5);
	this.instance_59.alpha = 0.1914;

	this.instance_60 = new lib.Symbol53();
	this.instance_60.setTransform(528.1,303.65,1,1,0,0,0,18.4,21.5);
	this.instance_60.alpha = 0.1914;

	this.instance_61 = new lib.Symbol52();
	this.instance_61.setTransform(501.75,289.4,1,1,0,0,0,23.4,19.1);
	this.instance_61.alpha = 0.1914;

	this.instance_62 = new lib.Symbol51();
	this.instance_62.setTransform(497.55,321.6,1,1,0,0,0,23.2,20.5);
	this.instance_62.alpha = 0.1914;

	this.instance_63 = new lib.Symbol50();
	this.instance_63.setTransform(521.8,340.65,1,1,0,0,0,30.4,15.5);
	this.instance_63.alpha = 0.1914;

	this.instance_64 = new lib.Symbol49();
	this.instance_64.setTransform(533.45,377.85,1,1,0,0,0,30.4,25.8);
	this.instance_64.alpha = 0.1914;

	this.instance_65 = new lib.Symbol48();
	this.instance_65.setTransform(516.35,393.15,1,1,0,0,0,27.7,21.7);
	this.instance_65.alpha = 0.1914;

	this.instance_66 = new lib.Symbol47();
	this.instance_66.setTransform(495.4,377.1,1,1,0,0,0,21.1,16.9);
	this.instance_66.alpha = 0.1914;

	this.instance_67 = new lib.Symbol46();
	this.instance_67.setTransform(485.7,359.15,1,1,0,0,0,20.8,19.6);
	this.instance_67.alpha = 0.1914;

	this.instance_68 = new lib.Symbol45();
	this.instance_68.setTransform(470.05,345.15,1,1,0,0,0,19.2,23.1);
	this.instance_68.alpha = 0.1914;

	this.instance_69 = new lib.Symbol44();
	this.instance_69.setTransform(448.35,333.65,1,1,0,0,0,21.9,18.8);
	this.instance_69.alpha = 0.1914;

	this.instance_70 = new lib.Symbol43();
	this.instance_70.setTransform(443.05,310.15,1,1,0,0,0,21.6,14.7);
	this.instance_70.alpha = 0.1914;

	this.lotc14 = new lib.Symbol42();
	this.lotc14.name = "lotc14";
	this.lotc14.setTransform(441.95,293.75,1,1,0,0,0,22.7,20.8);

	this.instance_71 = new lib.Symbol39();
	this.instance_71.setTransform(419.45,254.65,1,1,0,0,0,15.5,42.7);
	this.instance_71.alpha = 0.1914;

	this.instance_72 = new lib.Symbol38();
	this.instance_72.setTransform(448.55,251.3,1,1,0,0,0,20.8,22.2);
	this.instance_72.alpha = 0.1914;

	this.lotc23 = new lib.Symbol37();
	this.lotc23.name = "lotc23";
	this.lotc23.setTransform(467.15,239.3,1,1,0,0,0,16.8,19.5);
	this.lotc23.alpha = 0.1914;

	this.lotc22 = new lib.Symbol36();
	this.lotc22.name = "lotc22";
	this.lotc22.setTransform(483.55,226.8,1,1,0,0,0,17.4,18.9);

	this.lotc21 = new lib.Symbol35();
	this.lotc21.name = "lotc21";
	this.lotc21.setTransform(515.7,228.8,1,1,0,0,0,14.8,20.9);
	this.lotc21.alpha = 0.1914;

	this.instance_73 = new lib.Symbol34();
	this.instance_73.setTransform(538.25,242.2,1,1,0,0,0,15.2,17.4);
	this.instance_73.alpha = 0.1914;

	this.instance_74 = new lib.Symbol33();
	this.instance_74.setTransform(564.65,245.5,1,1,0,0,0,20.3,17.9);
	this.instance_74.alpha = 0.1914;

	this.instance_75 = new lib.Symbol32();
	this.instance_75.setTransform(556.55,216.2,1,1,0,0,0,33.8,25.2);
	this.instance_75.alpha = 0.1914;

	this.instance_76 = new lib.Symbol31();
	this.instance_76.setTransform(446.65,215.75,1,1,0,0,0,27.4,23.8);
	this.instance_76.alpha = 0.1914;

	this.instance_77 = new lib.Symbol30();
	this.instance_77.setTransform(377,212.55,1,1,0,0,0,57.2,23.1);
	this.instance_77.alpha = 0.1914;

	this.lot50 = new lib.Symbol29();
	this.lot50.name = "lot50";
	this.lot50.setTransform(359.2,262,1,1,0,0,0,60,56.6);

	this.instance_78 = new lib.Symbol28();
	this.instance_78.setTransform(318.65,376.75,1,1,0,0,0,67,90.4);
	this.instance_78.alpha = 0.1914;

	this.lot75 = new lib.Symbol29copy15();
	this.lot75.name = "lot75";
	this.lot75.setTransform(304.65,235.75,0.9746,0.9746,0,0,0,60.2,56.7);

	this.lot74 = new lib.Symbol29copy13();
	this.lot74.name = "lot74";
	this.lot74.setTransform(457.65,381.75,0.9746,0.9746,0,0,0,60.2,56.7);

	this.lot73 = new lib.Symbol29copy12();
	this.lot73.name = "lot73";
	this.lot73.setTransform(399.6,344.95,0.9746,0.9746,0,0,0,60.2,56.9);

	this.lot72 = new lib.Symbol29copy11();
	this.lot72.name = "lot72";
	this.lot72.setTransform(504.1,337.5,0.9746,0.9746,0,0,0,60.2,56.7);

	this.lot71 = new lib.Symbol29copy10();
	this.lot71.name = "lot71";
	this.lot71.setTransform(530.85,411.3,0.9746,0.9746,0,0,0,60.2,56.7);

	this.lot70 = new lib.Symbol29copy9();
	this.lot70.name = "lot70";
	this.lot70.setTransform(536.85,488.9,0.9746,0.9746,0,0,0,60.2,56.8);

	this.lot69 = new lib.Symbol29copy8();
	this.lot69.name = "lot69";
	this.lot69.setTransform(528.6,557.3,0.9746,0.9746,0,0,0,60.2,56.7);

	this.lot68 = new lib.Symbol29copy7();
	this.lot68.name = "lot68";
	this.lot68.setTransform(528.6,628.35,0.9746,0.9746,0,0,0,60.2,56.7);

	this.lot67 = new lib.Symbol29copy6();
	this.lot67.name = "lot67";
	this.lot67.setTransform(523.45,684.55,0.9746,0.9746,0,0,0,60.2,56.9);

	this.lot66 = new lib.Symbol29copy5();
	this.lot66.name = "lot66";
	this.lot66.setTransform(424.55,712.45,0.9746,0.9746,0,0,0,60.2,56.8);
	new cjs.ButtonHelper(this.lot66, 0, 1, 2, false, new lib.Symbol29copy5(), 3);

	this.lot65 = new lib.Symbol29copy4();
	this.lot65.name = "lot65";
	this.lot65.setTransform(404.75,664.2,0.9746,0.9746,0,0,0,60.1,56.8);

	this.lot64 = new lib.Symbol29copy3();
	this.lot64.name = "lot64";
	this.lot64.setTransform(396.45,610.15,0.9746,0.9746,0,0,0,60.1,56.8);

	this.lot63 = new lib.Symbol29copy2();
	this.lot63.name = "lot63";
	this.lot63.setTransform(389,558.5,0.9746,0.9746,0,0,0,60.2,56.8);

	this.lot62 = new lib.Symbol29copy();
	this.lot62.name = "lot62";
	this.lot62.setTransform(368.2,461.15,0.9746,0.9746,0,0,0,60.1,56.7);
	this.lot62.alpha = 0.1914;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.movieClip_1},{t:this.movieClip_2},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.movieClip_3},{t:this.instance}]}).to({state:[{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.lot32},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.lot61},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.lot55},{t:this.instance_13},{t:this.instance_12},{t:this.lot56},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7,p:{x:216.45,y:638.2}},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},1).to({state:[{t:this.instance_78},{t:this.lot50},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.lotc21},{t:this.lotc22},{t:this.lotc23},{t:this.instance_72},{t:this.instance_71},{t:this.lotc14},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.lot22},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_7,p:{x:717.6,y:555.85}},{t:this.instance_6}]},1).to({state:[{t:this.instance_7,p:{x:242.8,y:627.05}},{t:this.lot62},{t:this.lot63},{t:this.lot64},{t:this.lot65},{t:this.lot66},{t:this.lot67},{t:this.lot68},{t:this.instance_6},{t:this.lot69},{t:this.lot70},{t:this.lot71},{t:this.lot72},{t:this.lot73},{t:this.lot74},{t:this.lot75}]},1).wait(1));

	// Layer_2
	this.instance_79 = new lib.Symbol98();
	this.instance_79.setTransform(500,387.5,1,1.0026,0,0,0,500,386.5);

	this.instance_80 = new lib.Symbol97();
	this.instance_80.setTransform(500,386.5,1,1,0,0,0,500,386.5);

	this.instance_81 = new lib.Symbol95();
	this.instance_81.setTransform(500,386.5,1,1,0,0,0,500,386.5);

	this.instance_82 = new lib.BMTN_Map_Master88_newpngcopy2();
	this.instance_82.setTransform(0,0,0.5001,0.5001);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_79}]}).to({state:[{t:this.instance_80}]},1).to({state:[{t:this.instance_81}]},1).to({state:[{t:this.instance_82}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(500,386.5,500.79999999999995,387.70000000000005);
// library properties:
lib.properties = {
	id: '362B97526166454D95111F30419064D0',
	width: 1000,
	height: 773,
	fps: 24,
	color: "#000000",
	opacity: 1.00,
	manifest: [
		{src:"https://blackberrymtn.s3.amazonaws.com/assets/images/map/BMTN_Map_Master3pngcopy_newpngcopy3.png?1599231396856", id:"BMTN_Map_Master3pngcopy_newpngcopy3"},
		{src:"https://blackberrymtn.s3.amazonaws.com/assets/images/map/BMTN_Map_Master4_new.png?1599231396856", id:"BMTN_Map_Master4_new"},
		{src:"https://blackberrymtn.s3.amazonaws.com/assets/images/map/BMTN_Map_Master88_newpngcopy2.png?1599231396856", id:"BMTN_Map_Master88_newpngcopy2"},
		{src:"https://blackberrymtn.s3.amazonaws.com/assets/images/map/BMTN_Map_Master_5_new.jpg?1599231396856", id:"BMTN_Map_Master_5_new"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['362B97526166454D95111F30419064D0'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;